from pathlib import Path
import subprocess, hashlib, json, collections, re
root=Path(__file__).resolve().parent
e=root/'evidence/tes85-r7'; c=root/'candidate'
out=root/'results'; out.mkdir(exist_ok=True)
def git(*args): return subprocess.check_output(['git',*args],cwd=c)
r6='fa698dcfc5f143a5c5c372944dbafb2b2ae2577b'
r7='38aad73c26fbb2064d32ff4a9631f3e96d474faf'
result={'r6':r6,'r7':r7,'manifest':[]}
for line in (e/'MANIFEST.sha256').read_text().splitlines():
    digest,name=line.split('  ',1); f=e/name
    actual=hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else 'MISSING'
    result['manifest'].append({'file':name,'match':actual==digest})
assert all(x['match'] for x in result['manifest']), result['manifest']
assert git('rev-parse','HEAD^').decode().strip()==r6
names=git('diff','--name-only',r6,r7).decode().splitlines()
assert names==['server/internal/migrations/migrations_freeze_test.go','server/internal/migrations/migrations_lint_test.go']
result['changed_files']=names
assert git('diff',r6,r7)==(root/'incoming/R7-from-R6.patch').read_bytes()
for name in names: assert git('show',r7+':'+name)==(e/'source'/name).read_bytes()
result['trees']={}
for name in ['server/migrations','server/cmd/migrate']:
    a=git('rev-parse',r6+':'+name).decode().strip(); b=git('rev-parse',r7+':'+name).decode().strip()
    assert a==b; result['trees'][name]=a
groups=collections.defaultdict(list)
for f in git('ls-tree','--name-only',r6+':server/migrations').decode().splitlines():
    if f.endswith('.up.sql') and int(f.split('_')[0])>=129: groups[int(f.split('_')[0])].append(f[:-7])
collisions={str(k):sorted(v) for k,v in groups.items() if len(v)>1}
assert len(collisions)==25 and sum(map(len,collisions.values()))==63
assert collisions==json.loads((e/'migration-collisions.json').read_text(encoding='utf-8-sig'))
src=(e/'source/server/internal/migrations/migrations_lint_test.go').read_text()
frozen={k:re.findall(r'"([^"]+)"',v) for k,v in re.findall(r'^\s*(\d+):\s*\{([^}]+)\}',src,re.M)}
assert frozen==collisions
result['frozen_groups']=len(collisions); result['frozen_stems']=sum(map(len,collisions.values()))
result['patch_exact']=True
result['candidate_status']=git('status','--porcelain').decode()
assert not result['candidate_status']
(out/'object-verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
