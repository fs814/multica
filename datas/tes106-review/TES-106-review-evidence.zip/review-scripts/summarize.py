from pathlib import Path
import json, collections, subprocess, os, re, hashlib
r=Path(__file__).resolve().parent; e=r/'evidence/tes85-r7'; out=r/'results'; c=r/'candidate'
summary={}
for name,p in [('review-lint',out/'lint.log'),('review-regressions',out/'migration-packages-final.jsonl'),('submitted-full-migrations',e/'evidence/migration-lint.jsonl')]:
    events=[json.loads(s) for s in p.read_text().splitlines() if s.startswith('{')]
    counts=collections.Counter((v['Action'], 'subtest' if '/' in v['Test'] else 'test') for v in events if v.get('Test') and v['Action'] in ['pass','fail','skip'])
    summary[name]={a+'_'+b:n for (a,b),n in counts.items()}
    if name.startswith('review'): assert not any(n for (a,b),n in counts.items() if a in ['skip','fail'])
assert summary['review-lint']=={'pass_subtest':272,'pass_test':3}
assert summary['review-regressions']=={'pass_subtest':286,'pass_test':13}
db=json.loads((out/'database-results.json').read_text()); tests=json.loads((out/'migration-packages-final.json').read_text())
assert not db.get('failure') and tests['exit']==0 and tests['dropped']
assert all(x['dropped'] for x in db['cleanup'])
assert db['r6_binary_sha256']=='e6dbc4953e57b3f9e914c1eb52651477a005f35c34995ab2271f32891989b05e'
url=re.search(r'defaultTestDatabaseURL = "([^"]+)"',(c/'server/cmd/migrate/migrate_concurrent_test.go').read_text())[1]
names=[x['database'] for x in db['cleanup']]+[tests['database']]
q='SELECT datname FROM pg_database WHERE datname IN ('+','.join("'"+x+"'" for x in names)+')'
data=subprocess.check_output([str(out/'dbprobe.exe')],input=q.encode(),env=dict(os.environ,DATABASE_URL=url.rsplit('/',1)[0]+'/postgres?sslmode=disable'))
assert json.loads(data)==[]
summary['cleanup_verified_absent']=names
summary['git_status']=subprocess.check_output(['git','status','--porcelain'],cwd=c,text=True)
assert not summary['git_status']
summary['r6_binary_sha256']=db['r6_binary_sha256']
summary['r7_binary_sha256']=hashlib.sha256((out/'r7-migrate.exe').read_bytes()).hexdigest()
(out/'review-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
print(json.dumps(db,indent=2))
