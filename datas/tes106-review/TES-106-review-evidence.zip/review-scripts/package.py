from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent; workspace=r.parents[1]; delivery=workspace/'datas/tes106-review'
inputs=[]
for line in (r/'incoming/SHA256SUMS-TES-85-r7.txt').read_text().splitlines():
    expected,name=line.split('  ',1)
    actual=hashlib.sha256((r/'incoming'/name).read_bytes()).hexdigest()
    assert actual==expected
    inputs.append({'name':name,'sha256':actual})
(r/'results/input-checksums.json').write_text(json.dumps(inputs,indent=2))
files={'REVIEW.md':delivery/'REVIEW.md'}
for p in (r/'results').iterdir():
    if p.is_file() and p.suffix in ['.json','.jsonl','.log','.txt','.py']: files['results/'+p.name]=p
for p in r.glob('*.py'): files['review-scripts/'+p.name]=p
files['review-scripts/dbprobe.go']=r/'evidence/tes85-r7/reproduction/dbprobe.go'
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name+'\n' for name,p in sorted(files.items()))
zpath=delivery/'TES-106-review-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()): z.write(p,name)
    z.writestr('SHA256SUMS.txt',manifest)
with zipfile.ZipFile(zpath) as z: assert z.testzip() is None
(delivery/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in [delivery/'REVIEW.md',zpath]))
print('Packaged',len(files),'files;',zpath.stat().st_size,'bytes')
