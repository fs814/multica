from pathlib import Path
import subprocess, json, hashlib, os
root=Path(__file__).resolve().parent; c=root/'candidate'; e=root/'evidence/tes85-r7'; out=root/'results'
summary={}
def run(label,args):
    with (out/(label+'.log')).open('wb') as f:
        p=subprocess.run(args,cwd=c/'server',stdout=f,stderr=subprocess.STDOUT)
    summary[label]=p.returncode
    (out/'checks-summary.json').write_text(json.dumps(summary,indent=2))
    print(label,p.returncode,flush=True)
    assert p.returncode==0, label
run('lint',['go','test','./internal/migrations','-run','TestMigration|TestHistoricalMigration','-count=1','-json'])
run('vet',['go','vet','./internal/migrations'])
run('build-probe',['go','build','-o',str(out/'dbprobe.exe'),str(e/'reproduction/dbprobe.go')])
run('build-r7',['go','build','-o',str(out/'r7-migrate.exe'),'./cmd/migrate'])
meta=subprocess.check_output(['go','version','-m',str(out/'r7-migrate.exe')],text=True)
assert 'vcs.revision=38aad73c26fbb2064d32ff4a9631f3e96d474faf' in meta and 'vcs.modified=false' in meta
(out/'r7-migrate.build.txt').write_text(meta)
zipname='TES-85-r6-windows-amd64.zip'
digest=next(line.split()[0] for line in (root/'r6/SHA256SUMS.txt').read_text().splitlines() if line.endswith(zipname))
assert hashlib.sha256((root/'r6'/zipname).read_bytes()).hexdigest()==digest
for name in ['rehearse.py','regressions.py']:
    s=(e/'reproduction'/name).read_text()
    s=s.replace("ROOT=Path.cwd(); candidate=ROOT/'.multica/tes85-r7'; evidence=ROOT/'.multica/tes85-r7-evidence'", "ROOT=Path(__file__).resolve().parent.parent; candidate=ROOT/'candidate'; evidence=ROOT/'results'")
    s=s.replace("root=Path.cwd(); c=root/'.multica/tes85-r7'; e=root/'.multica/tes85-r7-evidence'", "root=Path(__file__).resolve().parent.parent; c=root/'candidate'; e=root/'results'")
    s=s.replace("ROOT/'datas/tes85-r6/TES-85-r6-windows-amd64.zip'", "ROOT/'r6/TES-85-r6-windows-amd64.zip'")
    s=s.replace("ROOT/'datas/tes85-r6/proposal/migration-collisions.json'", "ROOT/'evidence/tes85-r7/migration-collisions.json'")
    s=s.replace("db='tes85_r7_'+mode", "db='tes85_r7_tes106_'+mode")
    s=s.replace("db='tes85_p0_r7_tests_'", "db='tes85_p0_r7_tes106_'")
    (out/name).write_text(s)
print('Builds and isolated rehearsal preparation complete.',flush=True)
