package main

import (
	"context"
	"errors"
	"testing"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"github.com/multica-ai/multica/server/internal/events"
	"github.com/multica-ai/multica/server/internal/realtime"
	"github.com/multica-ai/multica/server/internal/service"
	"github.com/multica-ai/multica/server/internal/util"
	db "github.com/multica-ai/multica/server/pkg/db/generated"
)

// requireSessionExcluded asserts a resume lookup found nothing BECAUSE the
// session was excluded — not because the query itself blew up.
//
// The bare `if err == nil && prior.SessionID.Valid` form these tests shared is
// false-green: any real fault (undefined column, syntax error, dead
// connection) makes err non-nil, the condition false, and the test pass. Run
// against a database missing this PR's new column, the exclusion tests
// reported PASS on a SQLSTATE 42703. Requiring pgx.ErrNoRows specifically is
// what makes a passing test mean "the filter worked".
func requireSessionExcluded(t *testing.T, sessionID pgtype.Text, err error) {
	t.Helper()
	if err == nil {
		t.Fatalf("expected the session to be excluded, but the lookup returned %q", sessionID.String)
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		t.Fatalf("lookup failed for an unrelated reason, so this test proves nothing: %v", err)
	}
}

// setupRerunTestFixture creates an issue assigned to the integration test
// agent and returns (issueID, agentID, runtimeID).
func setupRerunTestFixture(t *testing.T) (string, string, string) {
	t.Helper()
	ctx := context.Background()

	var agentID, runtimeID string
	if err := testPool.QueryRow(ctx, `
		SELECT a.id, a.runtime_id FROM agent a
		JOIN member m ON m.workspace_id = a.workspace_id
		JOIN "user" u ON u.id = m.user_id
		WHERE u.email = $1
		  AND a.archived_at IS NULL
		LIMIT 1
	`, integrationTestEmail).Scan(&agentID, &runtimeID); err != nil {
		t.Fatalf("failed to find test agent: %v", err)
	}

	var issueID string
	// Pick the next per-workspace number to avoid colliding with the
	// uq_issue_workspace_number unique constraint when multiple fixtures
	// coexist in the same test (e.g. TestRerunIssueRejectsCrossIssueTask).
	if err := testPool.QueryRow(ctx, `
		INSERT INTO issue (workspace_id, title, status, priority, creator_type, creator_id, assignee_type, assignee_id, number)
		SELECT $1, 'Rerun test issue', 'todo', 'none', 'member', m.user_id, 'agent', $2,
		       (SELECT COALESCE(MAX(number), 0) + 1 FROM issue WHERE workspace_id = $1)
		FROM member m WHERE m.workspace_id = $1 LIMIT 1
		RETURNING id
	`, testWorkspaceID, agentID).Scan(&issueID); err != nil {
		t.Fatalf("failed to create test issue: %v", err)
	}

	return issueID, agentID, runtimeID
}

func cleanupRerunFixture(t *testing.T, issueID string) {
	t.Helper()
	ctx := context.Background()
	testPool.Exec(ctx, `DELETE FROM agent_task_queue WHERE issue_id = $1`, issueID)
	testPool.Exec(ctx, `DELETE FROM issue WHERE id = $1`, issueID)
}

// TestGetLastTaskSessionExcludesPoisonedFailures asserts that the
// (agent_id, issue_id) resume lookup skips failed tasks whose
// failure_reason classifies them as poisoned terminal output. This is the
// SQL-level half of the rerun-poisoned-session fix: without the filter, a
// rerun would inherit the same session and replay the same bad output.
func TestGetLastTaskSessionExcludesPoisonedFailures(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Insert an older failed task with a poisoned classifier and a session_id.
	// The poisoned task is the *most recent* one, so without the filter the
	// resume lookup would return its session_id.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'HEALTHY-SESSION', '/tmp/healthy', 'timeout')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert healthy failed task: %v", err)
	}

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'POISONED-SESSION', '/tmp/poisoned', 'iteration_limit')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid {
		t.Fatal("expected to fall back to the healthy failed session, got no session")
	}
	if prior.SessionID.String == "POISONED-SESSION" {
		t.Fatal("rerun would inherit poisoned session — filter is not active")
	}
	if prior.SessionID.String != "HEALTHY-SESSION" {
		t.Fatalf("expected HEALTHY-SESSION, got %q", prior.SessionID.String)
	}
}

// TestGetLastTaskSessionFallsBackWhenLatestSessionBlanked is the claim-side
// half of MUL-5305: when the most recent task recorded NO session_id (the
// daemon withheld an unresumable Codex session so it would not poison the next
// follow-up), the resume lookup skips that row via `session_id IS NOT NULL`
// and falls back to the most recent task that does have a session — so the next
// follow-up continues from the last real conversation instead of the dropped
// pointer that produced the reported regression.
func TestGetLastTaskSessionFallsBackWhenLatestSessionBlanked(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Older completed task with a good, recorded session (its rollout is real).
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'OLD-GOOD-SESSION', '/tmp/good')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert older completed task: %v", err)
	}

	// Newer failed task whose unresumable session was withheld (session_id NULL).
	// This is the row a naive lookup would return, cold-starting the next run.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', NULL, '/tmp/blanked', 'timeout')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert newer blanked task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid {
		t.Fatal("expected fallback to the older recorded session, got no session")
	}
	if prior.SessionID.String != "OLD-GOOD-SESSION" {
		t.Fatalf("expected OLD-GOOD-SESSION, got %q", prior.SessionID.String)
	}
}

// TestGetLastTaskSessionExcludesEmptyHistoryMessage is the SQL half of the
// GH #6066 fix. The daemon now classifies an empty-message rejection as
// api_invalid_request, but daemons upgrade on their own cadence — a self-host
// install still running an older one writes agent_error.unknown, and only the
// query's text guard keeps the next task off the poisoned session. This drives
// that exact row shape.
func TestGetLastTaskSessionExcludesEmptyHistoryMessage(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// The row an un-upgraded daemon writes for GH #6066: the reason is the
	// catchall, so the failure_reason blacklist does not fire.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'POISONED-EMPTY-MSG', '/tmp/poisoned', 'agent_error.unknown',
		        'Invalid request: the message at position 37 with role ''assistant'' must not be empty')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionKeepsToolEmptinessError is the narrowness half: the
// text guard must not swallow a healthy session because some tool complained
// that a field was empty. A false positive here silently drops conversation
// context on every follow-up, which is worse than the bug it guards against.
func TestGetLastTaskSessionKeepsToolEmptinessError(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'HEALTHY-SESSION', '/tmp/healthy', 'agent_error.unknown',
		        'validation error: field must not be empty')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid || prior.SessionID.String != "HEALTHY-SESSION" {
		t.Fatalf("a tool emptiness error must not retire the session, got %+v", prior.SessionID)
	}
}

// TestGetLastTaskSessionExcludesAuthResolutionFailure is the SQL half of the
// auth-resolution resume fix: a provider that cannot resolve its own
// authentication method (no api_key / auth_token / header) fails deterministically
// on resume, so the (agent_id, issue_id) lookup must not hand the same dead
// session to the next task. The row carries agent_error.unknown — what every
// daemon version writes for this text — so only the ILIKE guard drops it, which
// is what un-wedges an issue stuck before the fix deployed without a daemon
// upgrade.
func TestGetLastTaskSessionExcludesAuthResolutionFailure(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'POISONED-AUTH', '/tmp/poisoned', 'agent_error.unknown',
		        'hermes provider error: "Could not resolve authentication method. Expected either api_key or auth_token to be set. Or for one of the X-Api-Key or Authorization headers to be explicitly omitted"')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionKeepsSessionOnAuthAdjacentError is the narrowness half:
// the ILIKE guard must match the exact provider phrase, not any error that
// merely talks about authentication. A false positive silently drops
// conversation context on every follow-up, which is worse than the bug it
// guards against.
func TestGetLastTaskSessionKeepsSessionOnAuthAdjacentError(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'HEALTHY-AUTH', '/tmp/healthy', 'agent_error.unknown',
		        'hermes provider error: could not resolve an authentication method for this model')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid || prior.SessionID.String != "HEALTHY-AUTH" {
		t.Fatalf("an auth-adjacent but non-matching error must not retire the session, got %+v", prior.SessionID)
	}
}

// TestCompletedTaskRolloutMissingWithholdsAndDisclosesGap is the cross-layer
// regression for MUL-5305 Must-fix 1: a COMPLETED follow-up whose Codex rollout
// is missing (the #5934 case — the user waits for each turn to finish) must (1)
// NOT be handed to the next follow-up as its resume pointer, and (2) NOT be
// resumed silently — the next claim must still disclose the continuity gap. It
// drives the REAL terminal write (CompleteAgentTask with session_rollout_missing,
// which clears session_id and flags the row in one statement) rather than a
// manual marker, then checks GetLastTaskSession (falls back to the older good
// session) + GetLatestTaskRolloutMissing (the disclosure signal
// buildClaimedTaskResponse reads).
func TestCompletedTaskRolloutMissingWithholdsAndDisclosesGap(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()
	queries := db.New(testPool)

	// Older completed turn with a real, recorded session.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'OLD-GOOD-SESSION', '/tmp/good')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert older completed task: %v", err)
	}

	// Newer turn still 'running' with a mid-flight-pinned session — exactly the
	// pointer the reported bug propagates. CompleteAgentTask below finishes it
	// with session_rollout_missing=true (the daemon found no rollout).
	var newerTaskID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'running', 0, now() - interval '1 minute', 'NEW-ROLLOUT-MISSING', '/tmp/newer')
		RETURNING id
	`, agentID, runtimeID, issueID).Scan(&newerTaskID); err != nil {
		t.Fatalf("insert newer running task: %v", err)
	}

	// The real terminal write withholds the session and flags the row atomically.
	done, err := queries.CompleteAgentTask(ctx, db.CompleteAgentTaskParams{
		ID:                    pgtype.UUID{Bytes: parseUUIDBytes(newerTaskID), Valid: true},
		Result:                []byte(`{"output":"done"}`),
		SessionID:             pgtype.Text{String: "NEW-ROLLOUT-MISSING", Valid: true},
		WorkDir:               pgtype.Text{String: "/tmp/newer", Valid: true},
		SessionRolloutMissing: true,
	})
	if err != nil {
		t.Fatalf("CompleteAgentTask: %v", err)
	}
	// The terminal SQL forced the pinned session NULL and flagged the row in one
	// statement — not two writes that a concurrent retry could interleave.
	if done.SessionID.Valid {
		t.Fatalf("expected withheld session_id to be NULL, got %q", done.SessionID.String)
	}
	if !done.SessionRolloutMissing {
		t.Fatal("expected session_rollout_missing to be set on the terminal row")
	}

	// (1) The bad session is NOT handed out — resume falls back to the older good one.
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid || prior.SessionID.String != "OLD-GOOD-SESSION" {
		t.Fatalf("expected fallback to OLD-GOOD-SESSION, got valid=%v %q", prior.SessionID.Valid, prior.SessionID.String)
	}

	// (2) The gap is disclosed — the resume is NOT silently claimed as complete.
	missing, err := queries.GetLatestTaskRolloutMissing(ctx, db.GetLatestTaskRolloutMissingParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLatestTaskRolloutMissing failed: %v", err)
	}
	if !missing {
		t.Fatal("expected the continuity gap to be flagged so the next claim discloses it")
	}
}

// TestFailedTaskRolloutMissingForcesNullOverMidFlightPin covers the failure-path
// half of MUL-5305 Must-fix 1: FailAgentTask normally COALESCE-preserves a
// mid-flight-pinned session, which would let an auto-retry created in the SAME
// transaction inherit a rollout-missing pointer. With session_rollout_missing
// the terminal UPDATE forces session_id NULL and flags the row in ONE statement,
// so there is no window between the fail committing and a separate marker where
// the retry could observe the bad pointer or a false gap flag.
func TestFailedTaskRolloutMissingForcesNullOverMidFlightPin(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()
	queries := db.New(testPool)

	// Running task with a mid-flight-pinned session, as UpdateAgentTaskSession
	// would have left it before the run failed with no rollout on disk.
	var taskID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'running', 0, now() - interval '1 minute', 'PINNED-BUT-NO-ROLLOUT', '/tmp/wd')
		RETURNING id
	`, agentID, runtimeID, issueID).Scan(&taskID); err != nil {
		t.Fatalf("insert running task: %v", err)
	}

	// The daemon withheld it: FailTask sends an empty session_id (Valid:false)
	// AND session_rollout_missing=true. The CASE must win over the COALESCE.
	failed, err := queries.FailAgentTask(ctx, db.FailAgentTaskParams{
		ID:                    pgtype.UUID{Bytes: parseUUIDBytes(taskID), Valid: true},
		Error:                 pgtype.Text{String: "runtime went offline", Valid: true},
		FailureReason:         pgtype.Text{String: "timeout", Valid: true},
		SessionID:             pgtype.Text{Valid: false},
		WorkDir:               pgtype.Text{Valid: false},
		SessionRolloutMissing: true,
	})
	if err != nil {
		t.Fatalf("FailAgentTask: %v", err)
	}
	if failed.SessionID.Valid {
		t.Fatalf("expected the mid-flight pin to be forced NULL, got %q", failed.SessionID.String)
	}
	if !failed.SessionRolloutMissing {
		t.Fatal("expected session_rollout_missing to be set on the failed row")
	}
}

// TestGetLastTaskSessionFallbackPoisonedClassifier covers the second
// poisoned classifier so adding a third doesn't silently break this rule.
func TestGetLastTaskSessionFallbackPoisonedClassifier(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '5 seconds', now() - interval '5 seconds', 'POISONED-FALLBACK', '/tmp/poisoned', 'agent_fallback_message')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionExcludesAPIInvalidRequest covers the MUL-1921
// case: an Anthropic 400 invalid_request_error (e.g. an oversized or
// malformed image baked into the conversation) bakes the bad message
// into the session history, so resuming would replay the same 400
// forever. The daemon classifies these as 'api_invalid_request' and the
// SQL filter must skip them on the resume lookup.
func TestGetLastTaskSessionExcludesAPIInvalidRequest(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '5 seconds', now() - interval '5 seconds', 'POISONED-API400', '/tmp/poisoned', 'api_invalid_request')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionExcludesCodexSemanticInactivity covers Codex
// semantic inactivity timeouts: the failed task did establish a session, but
// resuming it can replay the same stuck Codex state. The resume lookup must
// skip that session.
func TestGetLastTaskSessionExcludesCodexSemanticInactivity(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'HEALTHY-SESSION', '/tmp/healthy', 'timeout')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert healthy failed task: %v", err)
	}

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'CODEX-STUCK-SESSION', '/tmp/codex-stuck', 'codex_semantic_inactivity',
		        'codex semantic inactivity timeout after 10m0s without agent progress (last activity: tool-result:exec_command)')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert codex semantic inactivity task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if prior.SessionID.String != "HEALTHY-SESSION" {
		t.Fatalf("expected HEALTHY-SESSION, got %q", prior.SessionID.String)
	}
}

func TestCreateRetryTaskFreshensCodexSemanticInactivity(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	var parentID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (
			agent_id, runtime_id, issue_id, status, priority,
			started_at, completed_at, session_id, work_dir, failure_reason,
			attempt, max_attempts
		)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute',
		        'CODEX-STUCK-SESSION', '/tmp/codex-stuck', 'codex_semantic_inactivity', 1, 2)
		RETURNING id
	`, agentID, runtimeID, issueID).Scan(&parentID); err != nil {
		t.Fatalf("insert codex semantic inactivity parent task: %v", err)
	}

	queries := db.New(testPool)
	child, err := queries.CreateRetryTask(ctx, db.CreateRetryTaskParams{ID: pgtype.UUID{Bytes: parseUUIDBytes(parentID), Valid: true}})
	if err != nil {
		t.Fatalf("CreateRetryTask failed: %v", err)
	}
	if child.SessionID.Valid {
		t.Fatalf("expected retry child to drop poisoned session_id, got %q", child.SessionID.String)
	}
	if child.WorkDir.Valid {
		t.Fatalf("expected retry child to drop poisoned work_dir, got %q", child.WorkDir.String)
	}
	if !child.ForceFreshSession {
		t.Fatal("expected retry child to force a fresh session")
	}
	if child.Attempt != 2 {
		t.Fatalf("expected attempt 2, got %d", child.Attempt)
	}
}

func TestCreateRetryTaskKeepsOrdinaryTimeoutSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	var parentID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (
			agent_id, runtime_id, issue_id, status, priority,
			started_at, completed_at, session_id, work_dir, failure_reason,
			attempt, max_attempts
		)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute',
		        'ORDINARY-TIMEOUT-SESSION', '/tmp/ordinary-timeout', 'timeout', 1, 2)
		RETURNING id
	`, agentID, runtimeID, issueID).Scan(&parentID); err != nil {
		t.Fatalf("insert ordinary timeout parent task: %v", err)
	}

	queries := db.New(testPool)
	child, err := queries.CreateRetryTask(ctx, db.CreateRetryTaskParams{ID: pgtype.UUID{Bytes: parseUUIDBytes(parentID), Valid: true}})
	if err != nil {
		t.Fatalf("CreateRetryTask failed: %v", err)
	}
	if !child.SessionID.Valid || child.SessionID.String != "ORDINARY-TIMEOUT-SESSION" {
		t.Fatalf("expected retry child to inherit session_id, got %+v", child.SessionID)
	}
	if !child.WorkDir.Valid || child.WorkDir.String != "/tmp/ordinary-timeout" {
		t.Fatalf("expected retry child to inherit work_dir, got %+v", child.WorkDir)
	}
	if child.ForceFreshSession {
		t.Fatal("expected ordinary timeout retry child to keep resume enabled")
	}
	if child.Attempt != 2 {
		t.Fatalf("expected attempt 2, got %d", child.Attempt)
	}
}

// TestGetLastTaskSessionExcludesLegacyAPI400 is the MUL-1921 legacy
// regression: pre-fix rows are tagged failure_reason='agent_error' even
// though their error text contains the canonical Anthropic 400
// invalid_request_error marker. The daemon-side classifier only fires
// on new failures, so without a defensive ILIKE clause the resume query
// would happily return one of those rows on the next claim and
// re-poison every retry of an already-broken issue (e.g. MUL-1918,
// which already has three poisoned 'agent_error' rows when this PR
// merges). The SQL must skip the bad row on text shape alone.
func TestGetLastTaskSessionExcludesLegacyAPI400(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Legacy poisoned row: failure_reason was the pre-fix default
	// 'agent_error' but the error text shows it was an API 400
	// invalid_request_error. Migration 079 backfills these to
	// 'api_invalid_request', but the SQL filter must still exclude
	// them via ILIKE on the off chance a row escapes the migration
	// (deploy window, manual relabel, etc.).
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'LEGACY-POISONED', '/tmp/legacy', 'agent_error',
		        'API Error: 400 {"type":"error","error":{"type":"invalid_request_error","message":"Could not process image"}}')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert legacy poisoned task: %v", err)
	}

	// Newly classified poisoned row coexisting with the legacy one.
	// Without the ILIKE clause, ORDER BY completed_at DESC would
	// skip this row (failure_reason filter fires) and fall back to
	// the legacy row (failure_reason filter MISSES) — the exact
	// wormhole GPT-Boy flagged on PR review.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'NEW-POISONED', '/tmp/new', 'api_invalid_request',
		        'API Error: 400 {"type":"error","error":{"type":"invalid_request_error","message":"Could not process image"}}')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert new poisoned task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionKeepsBenignAgentErrorWithSession asserts the
// ILIKE clause is narrow enough that ordinary 'agent_error' failures
// (timeouts, tool errors, transient glue failures) still let the next
// task resume the prior session. Without this guard rail, the MUL-1921
// fix would regress MUL-1128's resume contract for everything else.
func TestGetLastTaskSessionKeepsBenignAgentErrorWithSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '30 seconds', now() - interval '30 seconds', 'HEALTHY-RESUMABLE', '/tmp/healthy', 'agent_error',
		        'tool execution failed: connection refused')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert benign failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid || prior.SessionID.String != "HEALTHY-RESUMABLE" {
		t.Fatalf("expected to resume HEALTHY-RESUMABLE, got %q (valid=%v)", prior.SessionID.String, prior.SessionID.Valid)
	}
}

// TestRerunIssueSetsForceFreshSession asserts the manual rerun flow flags
// the new task so the daemon claim handler skips the resume lookup. This
// is the call-site half of the fix: even if the SQL filter ever misses a
// poisoned classifier, manual rerun never resumes.
func TestRerunIssueSetsForceFreshSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, _, _ := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()
	queries := db.New(testPool)
	hub := realtime.NewHub()
	go hub.Run()
	bus := events.New()
	taskService := service.NewTaskService(queries, nil, hub, bus)

	task, err := taskService.RerunIssue(ctx, pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true}, pgtype.UUID{}, pgtype.UUID{}, pgtype.UUID{}, nil)
	if err != nil {
		t.Fatalf("RerunIssue failed: %v", err)
	}
	if task == nil {
		t.Fatal("RerunIssue returned nil task")
	}
	if !task.ForceFreshSession {
		t.Fatal("expected manual rerun to set force_fresh_session=true")
	}
}

// TestRerunIssueTargetsSourceTaskAgent asserts that when a source task ID is
// supplied (the execution-log retry-button path), the rerun targets the agent
// that ran that specific past task — not the issue's current assignee.
// Without this, clicking retry on a row whose agent has since been displaced
// (squad worker, @-mention agent, or a prior assignee) re-fires the new
// assignee instead, which is the MUL-2457 bug.
func TestRerunIssueTargetsSourceTaskAgent(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, primaryAgentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Create a second agent in the same workspace + runtime so we can stand
	// in as a "row whose agent is no longer the issue assignee" — e.g. a
	// squad worker or an @-mentioned agent. The issue's assignee is still
	// the primary agent; the rerun must target this secondary one because
	// that's whose task row the user clicked.
	var secondaryAgentID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent (
			workspace_id, name, description, runtime_mode, runtime_config,
			runtime_id, visibility, max_concurrent_tasks, owner_id
		)
		SELECT a.workspace_id, 'Rerun Secondary Agent', '', 'cloud', '{}'::jsonb,
		       a.runtime_id, 'workspace', 1, a.owner_id
		FROM agent a WHERE a.id = $1
		RETURNING id
	`, primaryAgentID).Scan(&secondaryAgentID); err != nil {
		t.Fatalf("create secondary agent: %v", err)
	}
	t.Cleanup(func() {
		testPool.Exec(ctx, `DELETE FROM agent_task_queue WHERE agent_id = $1`, secondaryAgentID)
		testPool.Exec(ctx, `DELETE FROM agent WHERE id = $1`, secondaryAgentID)
	})

	// Insert a failed past task on this issue under the secondary agent —
	// the row the user is about to click retry on.
	var sourceTaskID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority,
		                              started_at, completed_at, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0,
		        now() - interval '1 minute', now() - interval '30 seconds', 'agent_error')
		RETURNING id
	`, secondaryAgentID, runtimeID, issueID).Scan(&sourceTaskID); err != nil {
		t.Fatalf("insert source task: %v", err)
	}

	queries := db.New(testPool)
	hub := realtime.NewHub()
	go hub.Run()
	bus := events.New()
	taskService := service.NewTaskService(queries, nil, hub, bus)

	task, err := taskService.RerunIssue(
		ctx,
		pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
		pgtype.UUID{Bytes: parseUUIDBytes(sourceTaskID), Valid: true},
		pgtype.UUID{},
		pgtype.UUID{},
		nil,
	)
	if err != nil {
		t.Fatalf("RerunIssue failed: %v", err)
	}
	if task == nil {
		t.Fatal("RerunIssue returned nil task")
	}

	gotAgent := util.UUIDToString(task.AgentID)
	if gotAgent != secondaryAgentID {
		t.Fatalf("rerun targeted wrong agent: got %s, want %s (issue assignee is %s — must not be picked)",
			gotAgent, secondaryAgentID, primaryAgentID)
	}
	if !task.ForceFreshSession {
		t.Fatal("expected per-row rerun to also set force_fresh_session=true")
	}
}

// TestRerunIssueRejectsCrossIssueTask asserts a source task whose IssueID
// does not match the rerun target is rejected — both as defense-in-depth
// against malicious requests and because picking up an unrelated task's
// agent would silently misroute the rerun.
func TestRerunIssueRejectsCrossIssueTask(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueAID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueAID) })

	ctx := context.Background()

	// Second issue in the same workspace, with a task that does NOT belong
	// to issue A. The handler must reject this. Take the next available
	// per-workspace number so the uq_issue_workspace_number constraint
	// (both issues default to number=0 otherwise) doesn't fire before the
	// rerun assertion can.
	var issueBID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO issue (workspace_id, title, status, priority, creator_type, creator_id, assignee_type, assignee_id, number)
		SELECT $1, 'Rerun cross-issue test', 'todo', 'none', 'member', m.user_id, 'agent', $2,
		       (SELECT COALESCE(MAX(number), 0) + 1 FROM issue WHERE workspace_id = $1)
		FROM member m WHERE m.workspace_id = $1 LIMIT 1
		RETURNING id
	`, testWorkspaceID, agentID).Scan(&issueBID); err != nil {
		t.Fatalf("create second issue: %v", err)
	}
	t.Cleanup(func() { cleanupRerunFixture(t, issueBID) })

	var crossTaskID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority,
		                              started_at, completed_at, failure_reason)
		VALUES ($1, $2, $3, 'failed', 0,
		        now() - interval '1 minute', now() - interval '30 seconds', 'agent_error')
		RETURNING id
	`, agentID, runtimeID, issueBID).Scan(&crossTaskID); err != nil {
		t.Fatalf("insert cross task: %v", err)
	}

	queries := db.New(testPool)
	hub := realtime.NewHub()
	go hub.Run()
	bus := events.New()
	taskService := service.NewTaskService(queries, nil, hub, bus)

	_, err := taskService.RerunIssue(
		ctx,
		pgtype.UUID{Bytes: parseUUIDBytes(issueAID), Valid: true},
		pgtype.UUID{Bytes: parseUUIDBytes(crossTaskID), Valid: true},
		pgtype.UUID{},
		pgtype.UUID{},
		nil,
	)
	if err == nil {
		t.Fatal("expected RerunIssue to reject a source task from a different issue")
	}
}

// TestRerunIssueInheritsTriggerCommentFromSourceTask locks the trigger
// provenance contract: a per-row rerun of a comment- or mention-triggered
// task must carry the original trigger_comment_id through to the new task.
// Otherwise the daemon's buildCommentPrompt path (which keys on
// TriggerCommentID) is skipped and the rerun degrades into a generic
// issue run that has lost the original comment context — see MUL-2457
// review feedback.
func TestRerunIssueInheritsTriggerCommentFromSourceTask(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Create a comment to stand in as the original mention / reply trigger.
	var triggerCommentID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO comment (issue_id, workspace_id, author_type, author_id, content, type)
		SELECT $1, $2, 'member', m.user_id, 'please retry this', 'comment'
		FROM member m WHERE m.workspace_id = $2 LIMIT 1
		RETURNING id
	`, issueID, testWorkspaceID).Scan(&triggerCommentID); err != nil {
		t.Fatalf("insert trigger comment: %v", err)
	}
	t.Cleanup(func() {
		testPool.Exec(ctx, `DELETE FROM comment WHERE id = $1`, triggerCommentID)
	})

	// Source task carries the trigger_comment_id — this is the row whose
	// retry button the user clicks in the execution log.
	var sourceTaskID string
	if err := testPool.QueryRow(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority,
		                              started_at, completed_at, failure_reason,
		                              trigger_comment_id)
		VALUES ($1, $2, $3, 'failed', 0,
		        now() - interval '1 minute', now() - interval '30 seconds', 'agent_error',
		        $4)
		RETURNING id
	`, agentID, runtimeID, issueID, triggerCommentID).Scan(&sourceTaskID); err != nil {
		t.Fatalf("insert source task: %v", err)
	}

	queries := db.New(testPool)
	hub := realtime.NewHub()
	go hub.Run()
	bus := events.New()
	taskService := service.NewTaskService(queries, nil, hub, bus)

	task, err := taskService.RerunIssue(
		ctx,
		pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
		pgtype.UUID{Bytes: parseUUIDBytes(sourceTaskID), Valid: true},
		pgtype.UUID{},
		pgtype.UUID{},
		nil,
	)
	if err != nil {
		t.Fatalf("RerunIssue failed: %v", err)
	}
	if task == nil {
		t.Fatal("RerunIssue returned nil task")
	}
	if !task.TriggerCommentID.Valid {
		t.Fatal("expected per-row rerun to inherit trigger_comment_id from source task, got NULL")
	}
	if got := util.UUIDToString(task.TriggerCommentID); got != triggerCommentID {
		t.Fatalf("trigger_comment_id mismatch: got %s, want %s", got, triggerCommentID)
	}
}

// TestEnqueueTaskForIssueDoesNotForceFreshSession is the negative control
// for the rerun flag: the normal enqueue path must leave the flag false so
// auto-retry / comment-triggered tasks keep resuming the prior session
// (MUL-1128 contract).
func TestEnqueueTaskForIssueDoesNotForceFreshSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, _, _ := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()
	queries := db.New(testPool)
	hub := realtime.NewHub()
	go hub.Run()
	bus := events.New()
	taskService := service.NewTaskService(queries, nil, hub, bus)

	issue, err := queries.GetIssue(ctx, pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true})
	if err != nil {
		t.Fatalf("load issue: %v", err)
	}
	task, err := taskService.EnqueueTaskForIssue(ctx, issue)
	if err != nil {
		t.Fatalf("EnqueueTaskForIssue failed: %v", err)
	}
	if task.ForceFreshSession {
		t.Fatal("expected normal enqueue to leave force_fresh_session=false")
	}
}

// TestGetLastTaskSessionExcludesPoisonedOriginSession is the GH #5975 core
// regression: the SAME session_id appears on an older 'completed' row (the turn
// that first baked the oversized image into history) AND a newer poisoned
// 'failed' row (a later text-only turn that resumed it and hit the same
// rejection). A row-level filter would drop the poisoned row and fall back to
// the completed row — which points at the exact same dead session. The
// per-session-latest-state selection must invalidate the whole session.
func TestGetLastTaskSessionExcludesPoisonedOriginSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// Older completed row: the successful turn that consumed the oversized
	// screenshot and stored the session id.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'POISON-ORIGIN', '/tmp/origin')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert completed origin task: %v", err)
	}

	// Newer poisoned row on the SAME session: a later text-only turn resumed
	// it and hit the oversized-history-image rejection.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'POISON-ORIGIN', '/tmp/origin', 'api_invalid_request',
		        'kiro session/prompt failed: session/prompt: Internal error (code=-32603, data=Encountered an error in the response stream: messages.14.content.0.image.source.base64.data: At least one of the image dimensions exceed max allowed size: 8000 pixels)')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned resume task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionFallsBackToHealthyDistinctSession asserts that while a
// poisoned session (completed origin + newer poisoned resume, same id) is
// invalidated, a DIFFERENT healthy session on the same issue is still eligible.
func TestGetLastTaskSessionFallsBackToHealthyDistinctSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '3 minutes', now() - interval '3 minutes', 'POISON-ORIGIN', '/tmp/origin')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert completed origin task: %v", err)
	}
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'POISON-ORIGIN', '/tmp/origin', 'api_invalid_request',
		        'session/prompt: Internal error (code=-32603, data=messages.14.content.0.image.source.base64.data: At least one of the image dimensions exceed max allowed size: 8000 pixels)')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert poisoned resume task: %v", err)
	}
	// A separate, healthy session (distinct id) — the eligible fallback.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '1 minute', now() - interval '1 minute', 'HEALTHY-DISTINCT', '/tmp/healthy')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert healthy distinct task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if prior.SessionID.String != "HEALTHY-DISTINCT" {
		t.Fatalf("expected fallback to HEALTHY-DISTINCT, got %q", prior.SessionID.String)
	}
}

// TestGetLastTaskSessionExcludesKiroOversizedImageByText is the GH #5975
// defense-in-depth: a row that escaped the daemon classifier (still tagged
// 'agent_error', e.g. a new-server + old-daemon deploy window) must still be
// excluded on error-text shape alone via the oversized-image ILIKE clause.
func TestGetLastTaskSessionExcludesKiroOversizedImageByText(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', 'KIRO-OVERSIZED', '/tmp/kiro', 'agent_error',
		        'kiro session/prompt failed: session/prompt: Internal error (code=-32603, data=Encountered an error in the response stream: messages.14.content.0.image.source.base64.data: At least one of the image dimensions exceed max allowed size: 8000 pixels)')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert unclassified kiro oversized task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionRestoresRecoveredSession asserts the per-session-latest
// rule is symmetric: if a session that once failed poisoned later terminates
// cleanly again (a newer 'completed' row on the same id), it becomes resumable
// once more.
func TestGetLastTaskSessionRestoresRecoveredSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'RECOVER-SESS', '/tmp/recover', 'api_invalid_request',
		        'session/prompt: Internal error (code=-32603, data=messages.0.content.0.image.source.base64.data: At least one of the image dimensions exceed max allowed size: 8000 pixels)')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert earlier poisoned task: %v", err)
	}
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '1 minute', now() - interval '1 minute', 'RECOVER-SESS', '/tmp/recover')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert later completed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if prior.SessionID.String != "RECOVER-SESS" {
		t.Fatalf("expected the recovered session to be resumable again, got %q", prior.SessionID.String)
	}
}

// TestGetLastTaskSessionKeepsDimensionPhraseWithoutImageMarker is the
// review-tightening negative control: the oversized-image ILIKE now requires
// BOTH the dimension phrase AND the image-content marker, matching the Kiro
// detector / classifyPoisonedError precision. An unrelated error that merely
// mentions image dimensions (without the image.source.base64.data marker) must
// NOT be filtered — otherwise a benign failure would needlessly drop a
// resumable session.
func TestGetLastTaskSessionKeepsDimensionPhraseWithoutImageMarker(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '30 seconds', now() - interval '30 seconds', 'DIM-ONLY-RESUMABLE', '/tmp/dim', 'agent_error',
		        'tool reported: image dimensions exceed max allowed size: 8000 pixels while generating a thumbnail')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert dimension-phrase-only task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if !prior.SessionID.Valid || prior.SessionID.String != "DIM-ONLY-RESUMABLE" {
		t.Fatalf("expected the dimension-phrase-only session to stay resumable, got %q (valid=%v)", prior.SessionID.String, prior.SessionID.Valid)
	}
}

// TestGetLastTaskSessionExcludesOverflowedResumeFromOlderCompletedRow is the
// MUL-5722 topology, and the one the first attempt at the fix got wrong.
//
// A codex thread/resume that overflows the reader fails BEFORE any turn runs,
// so the backend has no session id to report and the failed row lands with
// session_id NULL. The thread it could not read is only named by the OLDER
// completed row. That means a row-level error-text filter on the failed row can
// never fire — `session_id IS NOT NULL` drops the row before any filter sees
// it — and the lookup happily returns the same oversized thread again.
//
// This is the shape every already-stuck issue is in right now, and the shape a
// daemon too old to classify the failure keeps producing, so the block has to
// key off the failure being newer than the candidate rather than off the failed
// row carrying the session.
func TestGetLastTaskSessionExcludesOverflowedResumeFromOlderCompletedRow(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	// The turn that grew the thread past the reader's cap. Perfectly healthy
	// looking: it completed, and it is the only row naming the thread.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'THR-OVERSIZED', '/tmp/codex')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert completed task: %v", err)
	}

	// The next turn resumed it and could not read the response back. No session
	// id, and the pre-fix daemon classifies it as the resume-SAFE
	// agent_error.process_failure — so only the error text identifies it.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', NULL, '/tmp/codex', 'agent_error.process_failure',
		        'codex thread/resume failed: codex process exited: bufio.Scanner: token too long')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert overflow failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}

// TestGetLastTaskSessionResumesAgainAfterOverflowRecovery is the other half of
// the time-based block above: it must expire, not latch. Once a fresh thread
// terminates after the overflow, that thread is resumable again — otherwise
// every later turn on the issue would start cold forever, trading a permanent
// stall for permanent amnesia.
func TestGetLastTaskSessionResumesAgainAfterOverflowRecovery(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '3 minutes', now() - interval '3 minutes', 'THR-OVERSIZED', '/tmp/codex')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert completed task: %v", err)
	}
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '2 minutes', now() - interval '2 minutes', NULL, '/tmp/codex', 'agent_error.process_failure',
		        'codex thread/resume failed: codex process exited: bufio.Scanner: token too long')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert overflow failed task: %v", err)
	}
	// The fresh-session retry that recovered the turn.
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '1 minute', now() - interval '1 minute', 'THR-FRESH', '/tmp/codex')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert recovered task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	if err != nil {
		t.Fatalf("GetLastTaskSession failed: %v", err)
	}
	if prior.SessionID.String != "THR-FRESH" {
		t.Fatalf("expected the post-overflow thread THR-FRESH, got %q", prior.SessionID.String)
	}
}

// TestGetLastTaskSessionExcludesOverflowRetiredSession covers the path a
// current daemon takes: it names the thread it could not read via
// retired_session_id, so the block does not have to rely on timing at all.
func TestGetLastTaskSessionExcludesOverflowRetiredSession(t *testing.T) {
	if testPool == nil {
		t.Skip("no database connection")
	}

	issueID, agentID, runtimeID := setupRerunTestFixture(t)
	t.Cleanup(func() { cleanupRerunFixture(t, issueID) })

	ctx := context.Background()

	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir)
		VALUES ($1, $2, $3, 'completed', 0, now() - interval '2 minutes', now() - interval '2 minutes', 'THR-OVERSIZED', '/tmp/codex')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert completed task: %v", err)
	}
	if _, err := testPool.Exec(ctx, `
		INSERT INTO agent_task_queue (agent_id, runtime_id, issue_id, status, priority, started_at, completed_at, session_id, work_dir, failure_reason, error, retired_session_id)
		VALUES ($1, $2, $3, 'failed', 0, now() - interval '1 minute', now() - interval '1 minute', NULL, '/tmp/codex', 'codex_resume_oversized',
		        'codex thread/resume failed: codex process exited: bufio.Scanner: token too long', 'THR-OVERSIZED')
	`, agentID, runtimeID, issueID); err != nil {
		t.Fatalf("insert overflow failed task: %v", err)
	}

	queries := db.New(testPool)
	prior, err := queries.GetLastTaskSession(ctx, db.GetLastTaskSessionParams{
		AgentID: pgtype.UUID{Bytes: parseUUIDBytes(agentID), Valid: true},
		IssueID: pgtype.UUID{Bytes: parseUUIDBytes(issueID), Valid: true},
	})
	requireSessionExcluded(t, prior.SessionID, err)
}
