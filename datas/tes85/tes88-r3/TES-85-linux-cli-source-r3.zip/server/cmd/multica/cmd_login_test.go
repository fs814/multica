package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/spf13/cobra"

	"github.com/multica-ai/multica/server/internal/cli"
)

func newLoginTestCmd() *cobra.Command {
	cmd := &cobra.Command{Use: "login"}
	cmd.Flags().String("token", "", "")
	cmd.Flags().String("profile", "", "")
	return cmd
}

func TestResolveLoginTokenServerURLDefaultsToCloud(t *testing.T) {
	setTestHome(t, t.TempDir())
	t.Setenv("MULTICA_SERVER_URL", "")

	if got := resolveLoginTokenServerURL(newLoginTestCmd()); got != defaultCloudServerURL {
		t.Fatalf("resolveLoginTokenServerURL() = %q, want %q", got, defaultCloudServerURL)
	}
}

func TestResolveLoginTokenServerURLPrefersConfiguredServer(t *testing.T) {
	t.Chdir(t.TempDir())
	setTestHome(t, t.TempDir())
	t.Setenv("MULTICA_SERVER_URL", "")
	// A stale host/container value is not proof that this process is running
	// inside a daemon task. Login still needs the selected human profile.
	t.Setenv("MULTICA_AGENT_ID", "")
	t.Setenv("MULTICA_TASK_ID", "")
	t.Setenv(cli.TaskConfigRootEnv, "")
	t.Setenv("MULTICA_DAEMON_PORT", "20032")
	cmd := newLoginTestCmd()
	if err := cmd.Flags().Set("profile", "jcode"); err != nil {
		t.Fatalf("set profile: %v", err)
	}
	if err := cli.SaveCLIConfigForProfile(cli.CLIConfig{ServerURL: "https://api.example.test/"}, "jcode"); err != nil {
		t.Fatalf("SaveCLIConfig: %v", err)
	}

	if got := resolveLoginTokenServerURL(cmd); got != "https://api.example.test" {
		t.Fatalf("resolveLoginTokenServerURL() = %q, want configured server", got)
	}
}

func TestRunLoginTokenAutoWatchesDiscoveredWorkspaces(t *testing.T) {
	t.Chdir(t.TempDir())
	setTestHome(t, t.TempDir())
	t.Setenv("MULTICA_TOKEN", "")
	t.Setenv("MULTICA_WORKSPACE_ID", "")
	// Regression for #6779: older container setups may leave this daemon-
	// injected task hint in the host environment. It must not block the
	// explicitly human login flow or hide the profile just written by it.
	t.Setenv("MULTICA_AGENT_ID", "")
	t.Setenv("MULTICA_TASK_ID", "")
	t.Setenv(cli.TaskConfigRootEnv, "")
	t.Setenv("MULTICA_DAEMON_PORT", "20032")

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer mul_test_token" {
			t.Fatalf("Authorization = %q, want bearer token", r.Header.Get("Authorization"))
		}
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/api/me":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"name":  "Ada",
				"email": "ada@example.com",
			})
		case r.Method == http.MethodGet && r.URL.Path == "/api/workspaces":
			_ = json.NewEncoder(w).Encode([]map[string]any{
				{"id": "ws-1", "name": "Alpha"},
				{"id": "ws-2", "name": "Beta"},
			})
		default:
			t.Fatalf("unexpected request: %s %s", r.Method, r.URL.Path)
		}
	}))
	defer srv.Close()
	t.Setenv("MULTICA_SERVER_URL", srv.URL)

	cmd := newLoginTestCmd()
	if err := cmd.Flags().Set("token", "mul_test_token"); err != nil {
		t.Fatalf("set token: %v", err)
	}
	if err := cmd.Flags().Set("profile", "jcode"); err != nil {
		t.Fatalf("set profile: %v", err)
	}

	stderr := captureStderr(t)
	err := runLogin(cmd, nil)
	errOut := stderr.read()
	if err != nil {
		t.Fatalf("runLogin: %v", err)
	}
	if !strings.Contains(errOut, "Found 2 workspace(s):") || !strings.Contains(errOut, "daemon start") {
		t.Fatalf("stderr = %q, want workspace discovery and daemon hint", errOut)
	}

	cfg, err := cli.LoadCLIConfigForProfile("jcode")
	if err != nil {
		t.Fatalf("LoadCLIConfig: %v", err)
	}
	if cfg.Token != "mul_test_token" || cfg.ServerURL != srv.URL || cfg.WorkspaceID != "ws-1" {
		t.Fatalf("config = %#v, want token, server URL, and first workspace", cfg)
	}
}
