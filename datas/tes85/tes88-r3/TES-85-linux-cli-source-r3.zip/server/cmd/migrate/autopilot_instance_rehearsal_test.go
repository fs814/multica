package main

import (
	"context"
	"fmt"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/multica-ai/multica/server/internal/migrations"
	"github.com/multica-ai/multica/server/internal/testutil"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestAutopilotInstanceMigrationRehearsal(t *testing.T) {
	if os.Getenv("MULTICA_RUN_MIGRATION_REHEARSAL") != "1" {
		t.Skip("opt-in isolated database rehearsal")
	}
	ctx := context.Background()
	cfg, err := pgxpool.ParseConfig(testDatabaseURL())
	if err != nil {
		t.Fatal("invalid database configuration")
	}
	admin, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		t.Fatal("cannot open rehearsal admin connection")
	}
	t.Cleanup(admin.Close)
	name := fmt.Sprintf("tes85_rehearsal_%d", time.Now().UnixNano())
	if _, err = admin.Exec(ctx, "CREATE DATABASE "+pgx.Identifier{name}.Sanitize()+" TEMPLATE template0"); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if _, err := admin.Exec(ctx, "DROP DATABASE "+pgx.Identifier{name}.Sanitize()); err != nil {
			t.Errorf("cleanup isolated database %s: %v", name, err)
		}
	})
	// Cleanup callbacks close the isolated pool, drop that database, then close admin.
	defer func() { t.Logf("isolated database: %s", name) }()
	dsn, parseErr := url.Parse(testDatabaseURL())
	if parseErr != nil || (dsn.Scheme != "postgres" && dsn.Scheme != "postgresql") {
		t.Fatal("rehearsal requires a PostgreSQL URL")
	}
	dsn.Path = "/" + name
	isolated := cfg.Copy()
	isolated.ConnConfig.Database = name
	pool, err := pgxpool.NewWithConfig(ctx, isolated)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)
	up, err := migrations.Files("up")
	if err != nil {
		t.Fatal(err)
	}
	opts := runOptions{Direction: "up", Files: up, Hooks: hooksForDirection("up"), Conditions: conditionsForDirection("up")}
	if err = runMigrations(ctx, pool, opts); err != nil {
		t.Fatal(err)
	}
	if err = runMigrations(ctx, pool, opts); err != nil {
		t.Fatalf("idempotent replay: %v", err)
	}
	fx := testutil.New(pool, "", "")
	user := fx.User(t, "Rehearsal", "tes85-rehearsal@example.invalid")
	ws := fx.Workspace(t, "Rehearsal", "tes85-rehearsal")
	ap := fx.Insert(t, "autopilot", testutil.Cols{"workspace_id": ws, "title": "Legacy", "assignee_id": user, "created_by_type": "member", "created_by_id": user})
	var down string
	for _, p := range up {
		if strings.HasSuffix(p, "517_autopilot_input_instance.up.sql") {
			down = strings.Replace(p, ".up.sql", ".down.sql", 1)
		}
	}
	if down == "" {
		t.Fatal("migration 517 absent")
	}
	applyDown := func() error {
		return runMigrations(ctx, pool, runOptions{Direction: "down", Files: []string{down}, Hooks: hooksForDirection("down"), Conditions: conditionsForDirection("down")})
	}
	if err = applyDown(); err != nil {
		t.Fatalf("legacy rollback: %v", err)
	}
	if err = runMigrations(ctx, pool, opts); err != nil {
		t.Fatal(err)
	}
	for _, assignment := range []string{
		"workflow_input_instance_revision=1",
		"workflow_input_instance_id=gen_random_uuid()",
		"workflow_input_instance_id=gen_random_uuid(), workflow_input_instance_revision=0",
		"workflow_input_instance_id=gen_random_uuid(), workflow_input_instance_revision=1, workflow_template_id=gen_random_uuid()",
		"workflow_input_instance_id=gen_random_uuid(), workflow_input_instance_revision=1, execution_mode='issue_pool'",
	} {
		if _, err = pool.Exec(ctx, "UPDATE autopilot SET "+assignment+" WHERE id=$1", ap); err == nil {
			t.Fatalf("invalid binding allowed: %s", assignment)
		}
	}
	fx.Exec(t, "UPDATE autopilot SET workflow_input_instance_id=gen_random_uuid(),workflow_input_instance_revision=1 WHERE id=$1", ap)
	if err = applyDown(); err == nil {
		t.Fatal("rollback silently removed active binding")
	}
	var present bool
	fx.QueryRow(t, "SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE version='517_autopilot_input_instance')").Scan(&present)
	if !present {
		t.Fatal("failed rollback removed ledger")
	}
	fx.Exec(t, "UPDATE autopilot SET workflow_input_instance_id=NULL,workflow_input_instance_revision=NULL WHERE id=$1", ap)
	if err = applyDown(); err != nil {
		t.Fatal(err)
	}
	if err = runMigrations(ctx, pool, opts); err != nil {
		t.Fatal(err)
	}
	// Exercise handlers and dispatcher against this database, not the workspace database.
	for _, pkg := range []string{"./internal/service", "./internal/handler"} {
		cmd := exec.Command("go", "test", pkg, "-run", "TestAutopilotInstance", "-count=1", "-v")
		cmd.Dir = filepath.Join("..", "..")
		env := []string{}
		for _, v := range os.Environ() {
			if !strings.HasPrefix(strings.ToUpper(v), "DATABASE_URL=") {
				env = append(env, v)
			}
		}
		cmd.Env = append(env, "DATABASE_URL="+dsn.String())
		output, err := cmd.CombinedOutput()
		t.Logf("%s\n%s", pkg, output)
		if err != nil {
			t.Fatalf("%s tests: %v", pkg, err)
		}
	}
}
