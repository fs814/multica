DROP INDEX CONCURRENTLY IF EXISTS issue_pool_notification_pkey_candidate;
