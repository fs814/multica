DROP INDEX CONCURRENTLY IF EXISTS issue_pool_notification_dedup_key;
