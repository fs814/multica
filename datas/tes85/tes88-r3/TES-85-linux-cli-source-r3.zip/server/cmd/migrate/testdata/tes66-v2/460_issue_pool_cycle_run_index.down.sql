DROP INDEX CONCURRENTLY IF EXISTS issue_pool_cycle_autopilot_run_key;
