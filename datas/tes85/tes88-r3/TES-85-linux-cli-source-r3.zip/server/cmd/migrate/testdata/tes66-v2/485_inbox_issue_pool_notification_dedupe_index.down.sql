DROP INDEX CONCURRENTLY IF EXISTS idx_inbox_issue_pool_notification_dedupe;
