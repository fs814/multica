"""Build the fixed TES-85 Linux CLI without modifying system installations."""
import argparse, hashlib, json, os, platform, stat, struct, subprocess
from pathlib import Path, PurePosixPath

COMMIT = '79afa3cfd14cf0b559324140c881e2ae50ab27e0'
VERSION = '0.4.42-tes85.79afa3cfd'
TOOLCHAIN = 'go1.26.6'
DATE = '2026-09-14T00:00:00Z'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_source(root, meta):
    """Verify all inputs, including assembly and arbitrary embed resources."""
    if meta.get('commit') != COMMIT or meta.get('toolchain') != TOOLCHAIN:
        raise SystemExit('Unexpected source commit or toolchain')
    files = meta['files']
    for name in files:
        path = PurePosixPath(name)
        if (not name or chr(92) in name or ':' in name or path.is_absolute()
                or '..' in path.parts or path.as_posix() != name):
            raise SystemExit('Unsafe source path: ' + name)
    expected = {name for name in files if name.startswith('server/')}
    actual = set()
    # No suffix filter: embed all: patterns can consume hidden files too.
    pending = [root / 'server']
    while pending:
        path = pending.pop()
        info = path.lstat()
        if (stat.S_ISLNK(info.st_mode)
                or getattr(info, 'st_file_attributes', 0) & 0x400):
            raise SystemExit('Source link/reparse point: ' + str(path))
        if stat.S_ISDIR(info.st_mode):
            pending.extend(path.iterdir())
        elif stat.S_ISREG(info.st_mode):
            actual.add(path.relative_to(root).as_posix())
        else:
            raise SystemExit('Non-regular source input: ' + str(path))
    if actual != expected:
        raise SystemExit('Source input set mismatch; added=' + repr(sorted(actual - expected))
                         + '; missing=' + repr(sorted(expected - actual)))
    for name, digest in files.items():
        path = root / name
        for parent in (path, *path.parents):
            if parent == root:
                break
            info = parent.lstat()
            if (stat.S_ISLNK(info.st_mode)
                    or getattr(info, 'st_file_attributes', 0) & 0x400):
                raise SystemExit('Source link/reparse point: ' + name)
        if not path.is_file() or sha(path) != digest:
            raise SystemExit('Source checksum mismatch: ' + name)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--arch',choices=['auto','amd64','arm64'],default='auto')
    p.add_argument('--cross',action='store_true',help='Allow cross compilation; never proves native acceptance')
    p.add_argument('--offline',action='store_true',help='Require a prewarmed toolchain/module cache')
    p.add_argument('--output',required=True,help='New output directory; existing artifacts are never overwritten')
    a=p.parse_args();root=Path(__file__).resolve().parent
    native={'x86_64':'amd64','amd64':'amd64','aarch64':'arm64','arm64':'arm64'}.get(platform.machine().lower())
    arch=native if a.arch=='auto' else a.arch
    if not arch:raise SystemExit('Unsupported architecture; record uname -m for engineering')
    if not a.cross and (platform.system()!='Linux' or arch!=native):raise SystemExit('Native Linux target required; use --cross only for build verification')
    meta=json.loads((root/'SOURCE.json').read_text(encoding='utf-8'))
    verify_source(root, meta)
    out=Path(a.output).resolve()
    if out == root or root in out.parents:raise SystemExit('Output must be outside the source package')
    if out.exists():raise SystemExit('Output already exists; choose a fresh directory')
    out.mkdir(parents=True)
    env=os.environ.copy();env.update(GOOS='linux',GOARCH=arch,CGO_ENABLED='0',GOTOOLCHAIN=TOOLCHAIN,GOENV='off',GOWORK='off',GOFLAGS='',GOAMD64='v1',GOARM64='v8.0',GOPRIVATE='',GONOSUMDB='',GONOPROXY='')
    env['GOPROXY']='off' if a.offline else 'https://proxy.golang.org'
    env['GOSUMDB']='sum.golang.org'
    if subprocess.check_output(['go','version'],env=env,text=True).split()[2]!=TOOLCHAIN:raise SystemExit('Exact Go 1.26.6 required')
    exe=out/'multica'
    flags=f'-s -w -buildid= -X main.version={VERSION} -X main.commit={COMMIT} -X main.date={DATE}'
    argv=['go','build','-mod=readonly','-trimpath','-buildvcs=false','-ldflags',flags,'-o',str(exe),'./cmd/multica']
    subprocess.run(argv,cwd=root/'server',env=env,check=True)
    for name in ('server/go.mod','server/go.sum'):
        if sha(root/name)!=meta['files'][name]:raise SystemExit('Dependency lock changed')
    raw=exe.read_bytes();machine=struct.unpack_from('<H',raw,18)[0]
    if raw[:4]!=b'\x7fELF' or raw[4:6]!=bytes([2,1]) or machine!=({'amd64':62,'arm64':183}[arch]):raise SystemExit('ELF architecture mismatch')
    metadata=subprocess.check_output(['go','version','-m',str(exe)],env=env,text=True)
    (out/'go-build-metadata.txt').write_text(metadata,encoding='utf-8')
    result={'commit':COMMIT,'version':VERSION,'toolchain':TOOLCHAIN,'os':'linux','arch':arch,'cgo':False,'source_manifest_sha256':sha(root/'SOURCE.json'),'binary_sha256':sha(exe),'bytes':len(raw),'native_execution':'not_run','build_host':platform.system(),'elf_machine':machine}
    (out/'BUILD.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()