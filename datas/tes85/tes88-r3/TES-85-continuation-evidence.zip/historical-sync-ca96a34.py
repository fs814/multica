"""Plan/create catalog instances without starting runs or triggers."""
import argparse, hashlib, json, subprocess, tempfile
from pathlib import Path

def call(cli, action, body):
    with tempfile.TemporaryDirectory(prefix="catalog-cli-") as tmp:
        path = Path(tmp)/"input.json"
        path.write_text(json.dumps({"schema_version":"1", **body}),encoding="utf-8")
        return json.loads(subprocess.check_output([cli,"workflow","call",action,"--input-file",str(path),"--output","json"],text=True,encoding="utf-8"))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--catalog",required=True);p.add_argument("--bindings",required=True)
    p.add_argument("--cli",default="multica");p.add_argument("--apply",action="store_true")
    p.add_argument("--output",required=True);p.add_argument("--platform");a=p.parse_args()
    bindings=json.loads(Path(a.bindings).read_text(encoding="utf-8"))
    rows=[];offset=0
    while True:
        page=call(a.cli,"instance.list",{"offset":offset,"limit":100,"include_archived":True})
        rows.extend(page["instances"]);offset+=len(page["instances"])
        if offset>=page["total"]:break
        if not page["instances"]:raise RuntimeError("pagination did not advance")
    existing={r["external_key"]:r for r in rows if r.get("managed_source")=="buildcatalog"}
    report=[]
    for manifest in sorted((Path(a.catalog)/"projects").glob("*.json")):
        data=manifest.read_bytes();project=json.loads(data);digest=hashlib.sha256(data).hexdigest()
        for target in project["targets"]:
            if a.platform and target["platform"]!=a.platform:continue
            item={"project_key":project["project_key"],"target_key":target["target_key"]}
            if target["review_status"]!="confirmed":
                report.append({**item,"status":"pending_review"});continue
            binding=bindings.get(target["platform"])
            if not binding:
                report.append({**item,"status":"missing_platform_template"});continue
            external=hashlib.sha256((project["project_key"]+"\0"+target["target_key"]).encode()).hexdigest()
            row=existing.get(external)
            if row:
                status="archived" if row.get("archived_at") else "unchanged"
                if row["input"].get("catalog_sha256")!=digest:status="conflict_review_catalog_change"
                report.append({**item,"status":status,"instance_id":row["id"],"revision":row["revision"]});continue
            body={"template_id":binding["template_id"],"name":(project["project_key"]+" / "+target["target_key"])[-100:],
                "description":"Managed by buildcatalog; review catalog changes before saving updates.",
                "idempotency_key":"buildcatalog:v1:"+external,
                "input":{"title":project["project_key"]+" / "+target["target_key"],
                    "description":"Execute the reviewed catalog target using the selected pipeline mode.",
                    **item,"catalog_sha256":digest,"pipeline_mode":"clone" if "clone" in target["supported_modes"] else "",
                    "supported_modes":", ".join(target["supported_modes"]),"ref":""}}
            template=call(a.cli,"template.get",{"template_id":binding["template_id"]})
            body["input_node"]=next(n for n in template["definition"]["nodes"] if n["key"]==template["definition"]["entry_node"])
            if binding.get("template_version_id"):body["template_version_id"]=binding["template_version_id"]
            if not a.apply:
                report.append({**item,"status":"create","external_key":external});continue
            # Unique workspace/idempotency_key fences concurrent creates and response-loss retries.
            row=call(a.cli,"instance.create",body)
            report.append({**item,"status":"saved","instance_id":row["id"],"revision":row["revision"],
                "version_bound":bool(row.get("template_version_id"))})
    Path(a.output).write_text(json.dumps({"instances":report,"runs_started":0,"triggers_created":0},indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"reconciled":len(report),"applied":a.apply,"runs_started":0}))
if __name__=="__main__":main()
