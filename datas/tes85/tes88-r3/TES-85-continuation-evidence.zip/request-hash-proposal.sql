-- Proposed only; not executed. Requires scope coordination.
ALTER TABLE workflow_run ADD COLUMN IF NOT EXISTS request_hash TEXT;
