import copy,unittest
from prepare_mac_routes import prepare
class RouteTests(unittest.TestCase):
 def setUp(self):
  self.c={'workspace_id':'10000000-0000-0000-0000-000000000001','machines':{'studio':{'agent_id':'20000000-0000-0000-0000-000000000001','runtime_id':'30000000-0000-0000-0000-000000000001','host_config':'/Users/operator/studio-host.json'},'book':{'agent_id':'20000000-0000-0000-0000-000000000002','runtime_id':'30000000-0000-0000-0000-000000000002','host_config':'/Users/operator/book-host.json'}}}
  self.t={'definition':{'schema_version':2,'nodes':[{'type':'agent','instruction':'run reviewed target','routing':{'strategy':'capability','capability':'settings-macos-runner'}}]}}
 def test_routes_explicit_and_source_unchanged(self):
  before=copy.deepcopy(self.t);r=prepare(self.c,self.t)
  self.assertEqual(before,self.t)
  for k,v in r.items():
   self.assertEqual({'strategy':'explicit','agent_id':self.c['machines'][k]['agent_id']},v['create_request']['definition']['nodes'][0]['routing'])
   self.assertFalse(v['ready_for_platform_execution']);self.assertFalse(v['instance_key_prefix'].startswith('buildcatalog:'))
  self.assertNotEqual(r['studio']['definition_sha256'],r['book']['definition_sha256'])
 def test_shared_runtime_rejected(self):
  self.c['machines']['book']['runtime_id']=self.c['machines']['studio']['runtime_id']
  with self.assertRaises(ValueError):prepare(self.c,self.t)
 def test_shared_agent_rejected(self):
  self.c['machines']['book']['agent_id']=self.c['machines']['studio']['agent_id']
  with self.assertRaises(ValueError):prepare(self.c,self.t)
 def test_invalid_host_rejected(self):
  self.c['machines']['studio']['host_config']='relative.json'
  with self.assertRaises(ValueError):prepare(self.c,self.t)
 def test_missing_identity_rejected(self):
  self.c['machines']['book']['agent_id']=''
  with self.assertRaises(ValueError):prepare(self.c,self.t)
if __name__=='__main__':unittest.main()