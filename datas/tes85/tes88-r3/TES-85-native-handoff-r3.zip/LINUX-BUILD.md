Dev Cloud 固定 Linux CLI 源码交付

源码 ZIP：TES-85-linux-cli-source-r3.zip（与本文一同附于工单）。固定产品提交
79afa3cfd14cf0b559324140c881e2ae50ab27e0，包含 server 完整 Go 源码/依赖锁、LICENSE、NOTICE、SOURCE.json 和构建脚本，无 Git 历史、认证 profile、数据库或预编译系统安装程序。
SHA256：7bdd511c78a089a7863539fe2ec3f1fd70c9d17903ffb54a785457b67510a108。
该本地工作流基线尚不能从 upstream main 直接取得；源码包避免依赖尚未发布的远端分支。它不代表正式 main release，也不升级服务。

1. 在 Dev Cloud 普通终端记录 `uname -m`、`uname -sr`、`cat /etc/os-release`、`python3 --version`、`go version`；在回执填写 VM/容器/WSL2、连接方式、目录/时段、目标 workspace/API 地址。不提供凭据值。x86_64 对应 amd64，aarch64/arm64 对应 arm64；其他架构停止并回传，不按 Ubuntu 名称推断 CPU。
2. 校验下载包后解压到独立目录：

    sha256sum TES-85-linux-cli-source-r3.zip
    python3 -m zipfile -e TES-85-linux-cli-source-r3.zip tes85-linux-source
    cd tes85-linux-source
    python3 build_linux_cli.py --arch auto --output ../linux-build-one
    ../linux-build-one/multica --version
    python3 build_linux_cli.py --arch auto --output ../linux-build-two
    sha256sum ../linux-build-one/multica ../linux-build-two/multica

脚本逐文件核对 SOURCE.json；固定 go1.26.6、CGO_ENABLED=0、GOAMD64=v1 / GOARM64=v8.0、trimpath、buildvcs=false、readonly 依赖锁和固定日期/version/commit。版本字符串为 0.4.42-tes85.79afa3cfd，commit 为完整 79afa...，这只是明确标识的验收候选。构建产出 BUILD.json、go-build-metadata.txt 以及本机 Linux CLI；输出目录必须不存在，不写 /usr/local/bin，不替换系统 Multica。

依赖：Python 3、支持固定 GOTOOLCHAIN 的 Go launcher，以及 Go 1.26.6 工具链和 go.sum 约束的模块。首次需访问 proxy.golang.org / sum.golang.org，或者已有完整缓存；不包含 Go 工具链、模块 vendor、Linux 包管理器安装及项目编译工具。脚本会在需要时由 Go 拉取固定工具链；无网络/缓存时如实失败。预热完成后可用 `--offline`，要求该 Linux 主机本身已有匹配工具链/模块缓存；Windows 缓存不能直接当 Linux 工具链使用。不要关闭模块校验以绕过失败。

已完成的构建验证：Windows 上从实际 ZIP 两个不同解压根为每种架构交叉构建，均得到相同 SHA256。amd64：d6a8c5d9079e34235e8e2356cd57737b7653fdc2d6a2367a2faf1ddb4a7d18c3；arm64：83b87874391125545deb08a0cbc112949d3fcae499817a6d9bbb46d8519764f6。ELF64 little-endian machine 分别 62/183，CGO 关闭。详见 linux-reproducibility.json。Linux 本机复现若摘要不同，保留元数据，不直接算失败或通过，交工程核对环境与源码；跨宿主的逐字节相同尚未实测。

当前 Dev Cloud 架构尚未确认，所以没有把任一交叉构建二进制作为该主机的交付产物。本机完成环境回执后可按对应架构提供固定产物。Linux 原生 --version、daemon 登录/注册/任务、目录权限、项目构建/run-only、取消及发行版/WSL2 差异均待实机验收。

Settings 执行器仍用已审 v8 中的 Settings 目录（20d15c7f）：可解压已下载的 v8 ZIP 取该目录并按其 SHA 校验，不在 Linux 执行其中的 Mac CLI。调用本次生成的 Linux CLI。先运行本地 Python/Git 验收，服务器未就绪时保留结果并标记“平台导入待部署”。Linux 实例需独立 Linux runtime/agent 和逐机 host 配置，不能指向两台 Mac 的 agent。

平台仍须满足第九批 OPERATIONS.md 的匹配 server/CLI/UI、保存实例能力、迁移/备份/健康和正式发布门槛。当前生产未切换；不得使用此源码包自行应用服务器迁移或覆盖 daemon。

R3 correction: all server file paths and content are verified before Go starts. Keep outputs outside the extracted source package. PM revision 2 is bundled unchanged; its historical source/handoff hashes are superseded by SHA256SUMS-r3.txt. Independent TES-88 re-review and native acceptance remain pending.
