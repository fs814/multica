TES-85 native handoff helpers (product remains 79afa3cfd)

build_linux_cli.py accompanies a source-only ZIP exported from the fixed product
commit (server + LICENSE + NOTICE). SOURCE.json contains the exact file SHA256s.
The helper requires Go 1.26.6, locks module edits, pins Linux CPU baselines and
build metadata, and emits a checked ELF plus BUILD.json. Native mode requires a
Linux host; --cross is explicit. --offline requires a prewarmed matching cache.
No system binary installation, login or daemon startup is performed.

prepare_mac_routes.py creates two local template requests with explicit agents.
Distinct Studio/Book runtime and agent UUIDs are required, along with each Mac's
absolute host config path. It does not query or mutate the platform. Live identity,
ownership, health, permission, published-version and native-result gates remain
mandatory. Plain acceptance instances use tes85-native-v8:* retry keys; using the
canonical buildcatalog:v1:* key on both machines would reuse one managed identity.
Agent runtime bindings remain mutable; this helper is not hardware fencing.

Run tests: python -m unittest discover -s e2e/delivery -p test_mac_routes.py -v
The source ZIP was built twice from different extraction roots for each of Linux
amd64 and arm64, with identical per-architecture binary SHA256s. Windows cross
builds and cached offline builds do not constitute Linux native acceptance.
R1 correction: build_linux_cli.py compares the entire server file set before
running Go or creating output, then verifies all manifest checksums. New Go,
assembly, cgo, object and embed resources (including hidden/nested files), missing
files, modified files and symlink/reparse inputs are rejected. Output must be
outside the source archive. Keep the source extraction immutable while building.
Use the externally delivered ZIP checksum as the trust anchor for SOURCE.json.

R2 correction: MAC-ROUTING.md delegates to bundled PM revision 2, with r3 archive
names/checksums replacing its historical download references. The original PM
files are included byte-for-byte. Mac v8 and product commit remain unchanged.

Run all helper regressions:
    python -m unittest discover -s e2e/delivery -p 'test_*.py' -v
