"""Source verification must reject changes before invoking Go or creating output."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import build_linux_cli as builder


class SourceGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'package'
        self.root.mkdir()
        (self.root / 'server/assets').mkdir(parents=True)
        for name, data in {'server/go.mod': b'module fixture',
                           'server/main.go': b'package main',
                           'server/assets/base.txt': b'embedded',
                           'LICENSE': b'license'}.items():
            (self.root / name).write_bytes(data)
        self.meta = {'commit': builder.COMMIT, 'toolchain': builder.TOOLCHAIN,
                     'files': {p.relative_to(self.root).as_posix():
                               hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in self.root.rglob('*') if p.is_file()}}
        (self.root / 'SOURCE.json').write_text(json.dumps(self.meta))
        self.out = self.root.parent / 'output'

    def reject_before_go(self):
        with patch.object(builder, '__file__', str(self.root / 'build_linux_cli.py')), \
                patch('sys.argv', ['builder', '--cross', '--arch', 'amd64',
                                   '--output', str(self.out)]), \
                patch.object(builder.subprocess, 'check_output') as check, \
                patch.object(builder.subprocess, 'run') as run:
            with self.assertRaises(SystemExit):
                builder.main()
            check.assert_not_called()
            run.assert_not_called()
        self.assertFalse(self.out.exists())

    def test_original_inputs(self):
        builder.verify_source(self.root, self.meta)

    def test_unlisted_build_inputs(self):
        for name in ['extra.go', 'extra_linux_arm64.go', 'extra.s', 'extra.S',
                     'extra.h', 'extra.c', 'extra.syso', 'go.work',
                     'assets/new.txt', 'assets/.hidden', 'assets/nested/resource',
                     'vendor/modules.txt', 'nested/go.mod']:
            with self.subTest(name=name):
                extra = self.root / 'server' / name
                extra.parent.mkdir(parents=True, exist_ok=True)
                extra.write_bytes(b'unlisted input')
                self.reject_before_go()
                extra.unlink()

    def test_missing_file(self):
        (self.root / 'server/main.go').unlink()
        self.reject_before_go()

    def test_changed_file(self):
        (self.root / 'server/assets/base.txt').write_bytes(b'changed')
        self.reject_before_go()

    def test_unsafe_manifest_paths(self):
        for name in ['../outside', '/absolute', 'server/../LICENSE', 'C:/outside',
                     'server\\\\main.go']:
            with self.subTest(name=name):
                meta = dict(self.meta, files=dict(self.meta['files'], **{name: '0' * 64}))
                with self.assertRaises(SystemExit):
                    builder.verify_source(self.root, meta)

    def test_output_inside_package(self):
        self.out = self.root / 'server' / 'output'
        self.reject_before_go()

    def test_directory_symlink(self):
        target = self.root.parent / 'external'
        target.mkdir()
        link = self.root / 'server' / 'external'
        try:
            link.symlink_to(target, target_is_directory=True)
        except OSError:
            self.skipTest('Host does not permit symlink creation')
        self.reject_before_go()
        link.unlink()


if __name__ == '__main__':
    unittest.main()

