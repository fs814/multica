"""Prepare two explicit Mac acceptance routes locally; makes no platform writes."""
import argparse,copy,hashlib,json,uuid
from pathlib import Path,PurePosixPath

def prepare(config,template):
    uuid.UUID(config['workspace_id'])
    machines=config['machines']
    if set(machines)!={'studio','book'}:raise ValueError('Exactly studio and book required')
    for field in ['agent_id','runtime_id']:
        values=[str(uuid.UUID(machines[k][field])) for k in machines]
        if len(set(values))!=2:raise ValueError('Distinct '+field+' required for each Mac')
    results={}
    for machine,record in machines.items():
        host=record['host_config']
        if not PurePosixPath(host).is_absolute() or any(c in host for c in '\r\n\0'):raise ValueError('Absolute single-line Mac host config path required')
        body=copy.deepcopy(template);body['schema_version']='1'
        body['key']='tes85-macos-'+machine+'-acceptance'
        body['name']='TES85 Mac '+machine+' native acceptance'
        definition=body['definition']
        nodes=[n for n in definition['nodes'] if n['type']=='agent']
        if len(nodes)!=1:raise ValueError('Expected one execution node')
        nodes[0]['routing']={'strategy':'explicit','agent_id':record['agent_id']}
        nodes[0]['instruction']+='\nAcceptance machine: '+machine+'. Expected runtime: '+record['runtime_id']+'. Use only host config '+host+'. Stop if the machine, package digest or host binding differs; do not substitute another host or install tools.'
        digest=hashlib.sha256(json.dumps(definition,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        results[machine]={'create_request':body,'definition_sha256':digest,'expected_agent_id':record['agent_id'],'expected_runtime_id':record['runtime_id'],'host_config':host,'instance_key_prefix':'tes85-native-v8:'+machine+':','managed_source_expected':'','ready_for_platform_execution':False}
    return results

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--template',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();config=json.loads(Path(a.config).read_text(encoding='utf-8'));template=json.loads(Path(a.template).read_text(encoding='utf-8'))
    result=prepare(config,template);out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    for machine,row in result.items():
        (out/(machine+'-template.create.json')).write_text(json.dumps(row['create_request'],indent=2),encoding='utf-8')
        (out/(machine+'-template.validate.json')).write_text(json.dumps({'schema_version':'1','definition':row['create_request']['definition']},indent=2),encoding='utf-8')
    (out/'routing-plan.json').write_text(json.dumps({'workspace_id':config['workspace_id'],'routes':result,'platform_writes':0,'execution_gate':'Verify live runtime, agent, published version, saved inputs and native receipt before run'},indent=2),encoding='utf-8')
    print(json.dumps({'routes':2,'platform_writes':0,'ready_for_platform_execution':False}))

if __name__=='__main__':main()