TES-85 v8 修订2：逐机结果回传（Mac Studio / MacBook / Dev Cloud Linux，各机复制一份）

填写时间点：该机接入或导入时。已知机器无需重新申报；不填写密码、token、私钥或数据库备份。

机器记录：Mac Studio / MacBook / Dev Cloud Linux（选一）
日期、起止时间、时区：
OS/发行版、实际版本或滚动快照、内核、架构：
运行环境：原生 / VM / 容器 / WSL2；Mac 是否原生终端：
Dev Cloud 连接方式/已有安全配置名称（不填凭据值）：
Settings/包目录：
源码根目录：
构建根目录：
日志根目录：
目录可写性：
Xcode/clang 或 gcc、Python、Git、make、可选 Rust/Cargo/CMake：
目标 Multica 工作区/服务位置与版本（不附登录配置）：
该机执行 agent/runtime（导入时填写，尚未配置可填待配置）：
包文件名、SHA256、VERSION.json：
Settings=20d15c7f；产品=79afa3cfd 是否匹配：

| 步骤 | 未执行/通过/失败 | 退出码及证据文件 | 缺项/现象 |
|---|---|---|---|
| 外层和内部摘要 | | | |
| v8 实际 ZIP 离线验证 | | Mac 单包应6场景，mac_native=true，network_calls=0 | 不代表模型下载 |
| 原生 fixture（逐套） | | | |
| mquickjs clone_build_run | | result.json、阶段日志；输出85 | |
| 同产物 run-only | | result.json 仅run阶段；输出85 | |
| 真实取消/超时（如执行） | | 取消130/超时124及进程/锁证据 | 未测不得填通过 |
| 可选 ripgrep/fmt/扫描 | | | |
| canonical受管初始化/后续同步（仅指定操作者） | | 原journal、实例对账 | 其他机器填不适用 |
| 本机普通实例创建/幂等重试 | | 独立ID/revision、managed_source为空、幂等键 | 不计8/8受管覆盖 |
| execute 路由/发布版本绑定 | | 当前机器的实际绑定 | |
| 平台 clone_build_run/run-only | | workflow run/step ID | 本地执行不能代替 |
| 本地停止/回退（如执行） | | | |

实际项目ref及源码SHA：
清单/脚本摘要：
产物路径、架构及版本：
本地 run-id、result.json 所在附件：
模板ID/发布版本、实例ID/revision、workflow run/step ID（未产生写原因）：
canonical受管操作者及原journal位置（不附凭据）：
本机专用模板key/发布版本/普通实例ID与另一台是否不同：
运行前后专用agent.runtime_id、online及心跳：
重绑/删除与相关模板编辑冻结：确认人、开始/结束时间/时区：
实际领取任务的task/runtime/daemon/机器与阶段日志关联证据：
是否发生重绑/路由变化/误落另一机，发生时已暂停及处理：
TES-88对应脚本/源码包的审查结论、固定提交及包SHA：
Linux源码包SOURCE.json摘要、BUILD.json、go-build-metadata.txt、两次本机构建摘要及实际--version（Mac填不适用）：
未验证范围/需要工程处理的缺口：
日志与回执附件列表：

另行汇总的待答项目（已有答案可引用，不重复作答）：
- Linux virtualbox 入口：保留 Kubernetes / 更正为 VirtualBox。
- PDFMathTranslate 完整仓库 URL。
- 旧模型凭据撤销/轮换状态（仅状态，不填值；与首批无需凭据的样本分开）。

确认：本机通过范围只对应以上记录，不代表另一台Mac、其他Linux组合或全部待启用目标已验收。