Mac routing handoff, TES-88 R2

The bundled MAC-USER-GUIDE-r3.md section 6 is the single
operating procedure. It replaces the older MAC-ROUTING.md. The r4 integrated guide corrects archive state and package commands while retaining
its r3 filename for compatibility. Unmodified PM revision 2 is retained under
provenance/ for traceability. Validate the r4 handoff and unchanged r3 source ZIP with SHA256SUMS-r4.txt.

Extract the original verified Mac v8 ZIP and the r4 handoff ZIP into separate
directories. PACKAGE is the absolute v8 extraction root; HANDOFF is the absolute
r4 handoff extraction root. CLI is "$PACKAGE/multica"; the template is
"$PACKAGE/settings/buildcatalog/templates/macos.json".

Generate requests locally (no API writes):
    python3 "$HANDOFF/prepare_mac_routes.py" --config "$HANDOFF/mac-machines.json" --template "$PACKAGE/settings/buildcatalog/templates/macos.json" --output "$HANDOFF/mac-routes"

Use the real package-root CLI for read-only identity checks and template validation,
following section 6 of the PM guide. Canonical initialization has one owner and
one journal. The original eight instances are archived historical records, not
active coverage. Preserve archival and current revisions; do not automatically
restore, adopt by similar input, or reinitialize. Read current per-ID archival,
revision and managed identity before reconciliation; stop if evidence is missing.
Each Mac uses its own ordinary acceptance instance, explicit agent,
runtime, published template version and retry key. Verify IDs and permissions
online; freeze rebinding and retain task/daemon placement evidence. The generator
is not runtime fencing and does not authorize publication or execution.

TES-88 R1 remains passed within the r3 independent review scope; R2 r4 re-review is pending. Mac/Linux native acceptance is pending.
apply_allowed=false; no production change is authorized by this archive.
