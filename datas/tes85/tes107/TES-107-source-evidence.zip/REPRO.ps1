param([Parameter(Mandatory=$true)][string]$UpstreamRepo, [switch]$IncludeFullSuite)
$ErrorActionPreference='Stop'
$candidate=Join-Path $PSScriptRoot 'candidate'
$evidence=Join-Path $PSScriptRoot 'evidence'
$bundle=Join-Path $PSScriptRoot 'TES-107-final.bundle'
$expected='4fc4d1ff2e9ab0688de33732f6c682ff6209cb64'
if (Test-Path -LiteralPath $candidate) { throw 'Use a fresh extraction directory; candidate already exists' }
# UpstreamRepo must contain prerequisite 9d18186e6e8cfa168d6053d33d652e86fadfc12b.
git clone --shared --no-checkout $UpstreamRepo $candidate
if ($LASTEXITCODE -ne 0) { throw 'Local prerequisite clone failed' }
git -C $candidate bundle verify $bundle
if ($LASTEXITCODE -ne 0) { throw 'Missing bundle prerequisite; acquire the exact upstream object first' }
git -C $candidate fetch $bundle 'refs/heads/tes107-final:refs/heads/tes107-final'
if ($LASTEXITCODE -ne 0) { throw 'Bundle import failed' }
git -C $candidate checkout tes107-final
if ($LASTEXITCODE -ne 0 -or (git -C $candidate rev-parse HEAD) -ne $expected) { throw 'Candidate mismatch' }
New-Item -ItemType Directory -Force $evidence | Out-Null
Push-Location (Join-Path $candidate 'server')
try {
    go version
    go build -o (Join-Path $evidence 'dbprobe.exe') (Join-Path $PSScriptRoot 'dbprobe.go')
    if ($LASTEXITCODE -ne 0) { throw 'dbprobe build failed' }
    go build -o (Join-Path $evidence 'migrate-bootstrap.exe') ./cmd/migrate
    if ($LASTEXITCODE -ne 0) { throw 'migrate build failed' }
} finally { Pop-Location }
# Requires the repository's existing local development PostgreSQL login and
# CREATE/DROP DATABASE rights. The scripts create ONLY uniquely named disposable
# databases and drop those exact names in finally blocks, never the default DB.
python (Join-Path $PSScriptRoot 'verify.py') final
if ($LASTEXITCODE -ne 0) { throw 'Evidence harness failed; inspect per-command exit codes' }
if ($IncludeFullSuite) {
    python (Join-Path $PSScriptRoot 'standard.py')
    if ($LASTEXITCODE -ne 0) { throw 'Full-suite harness failed' }
}
Write-Output 'Execution receipts are in evidence/*.json. Harness completion is not test PASS; check every command exit and skip count.'
