from pathlib import Path
import os, re, subprocess, json, datetime, sys

root = Path(__file__).resolve().parent
candidate = root / 'candidate'
evidence = root / 'evidence'
evidence.mkdir(exist_ok=True)
url = re.search(r'defaultTestDatabaseURL = "([^"]+)"', (candidate/'server/cmd/migrate/migrate_concurrent_test.go').read_text())[1]
database = 'tes85_p0_r7_tes107_' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
def db_env(name):
    return dict(os.environ, DATABASE_URL=url.rsplit('/',1)[0]+'/'+name+'?sslmode=disable')
def sql(statement, db='postgres'):
    p = subprocess.run([str(evidence/'dbprobe.exe'), 'exec'], input=statement.encode(), env=db_env(db), capture_output=True)
    if p.returncode: raise RuntimeError('Database administration failed: '+p.stderr.decode(errors='replace'))

def run(name, args, env):
    print(name, 'running', flush=True)
    with (evidence/(name+'.log')).open('wb') as f:
        p = subprocess.run(args, cwd=candidate/'server', env=env, stdout=f, stderr=subprocess.STDOUT)
    events=[]
    for line in (evidence/(name+'.log')).read_text(errors='replace').splitlines():
        try: events.append(json.loads(line))
        except ValueError: pass
    result={'command':args,'exit':p.returncode, 'database':database,
            'counts':{a:sum(x.get('Action')==a and bool(x.get('Test')) and '/' not in x['Test'] for x in events) for a in ['pass','fail','skip']},
            'failures':[x for x in events if x.get('Action')=='fail'],
            'skips':[x for x in events if x.get('Action')=='skip']}
    (evidence/(name+'.json')).write_text(json.dumps(result,indent=2))
    print(name, p.returncode, result['counts'],flush=True)
    return p.returncode

mode=sys.argv[1]
owned=False
try:
    sql('CREATE DATABASE "'+database+'"'); owned=True
    env=db_env(database)
    if run(mode+'-migrate',[str(evidence/'migrate-bootstrap.exe'),'up'],env): raise RuntimeError('migration failed')
    if mode=='before':
        run('before-windows',['go','test','./internal/handler','-run','TestStableIDSuffixMatchesDaemon|TestParseSkillArchive','-count=1','-json'],env)
    elif mode=='final':
        run('build',['go','build','./...'],env)
        run('vet',['go','vet','./...'],env)
        run('focused',['go','test','-p','1','./internal/handler','./internal/service','./cmd/server','./internal/workflow','-run','TestR5|TestR6|TestWorkflow|TestAgentInvoke|TestBatchChildDone|TestBatchUpdate|TestStableIDSuffixMatchesDaemon|TestParseSkillArchive','-count=1','-json'],env)
        env['TES85_RUN_MIGRATION_TESTS']='1'
        run('migrations',['go','test','-p','1','./internal/migrations','./cmd/migrate','-run','TestMigration|TestHistoricalMigration|TestTES85','-count=1','-json'],env)
        env.pop('TES85_RUN_MIGRATION_TESTS')
        run('handler',['go','test','./internal/handler','-count=1','-json'],env)
    else: raise RuntimeError('unknown mode')
finally:
    if owned:
        sql('DROP DATABASE "'+database+'"')
        (evidence/(mode+'-database.json')).write_text(json.dumps({'database':database,'created':True,'dropped':True}))
        print('database dropped',database,flush=True)
