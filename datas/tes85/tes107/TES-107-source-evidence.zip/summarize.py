from pathlib import Path
import json, collections, re, os, subprocess
r=Path(__file__).resolve().parent;e=r/'evidence'
all_results={}
for name in ['focused','migrations','handler','standard-regular','standard-agent','race-regular','race-agent']:
    events=[]
    for line in (e/(name+'.log')).read_text(errors='replace').splitlines():
        try: events.append(json.loads(line))
        except ValueError: pass
    counts=collections.Counter(x.get('Action') for x in events if x.get('Test') and '/' not in x['Test'] and x.get('Action') in ['pass','fail','skip'])
    package_fails=[x.get('Package') for x in events if x.get('Action')=='fail' and not x.get('Test')]
    build_fails=sorted({x.get('ImportPath','') for x in events if x.get('Action')=='build-fail'})
    failnames={x.get('Test') for x in events if x.get('Action')=='fail' and x.get('Test')}
    reasons={}
    for x in events:
        if x.get('Test') in failnames and x.get('Action')=='output' and not x.get('Output','').startswith(('===','---','    ---')):
            reasons.setdefault(x.get('Test'),[]).append(x.get('Output',''))
    reasons={k:v[:6] for k,v in reasons.items()}
    result={'counts':dict(counts),'package_failures':package_fails,'build_failures':build_fails,'failure_outputs':reasons}
    all_results[name]=result
    print(name,dict(counts),'package failures',len(package_fails),'build failures',len(build_fails))
    if name=='standard-regular':print('\n'.join(package_fails))
(e/'TEST-RESULTS.json').write_text(json.dumps(all_results,indent=2))

dburl=re.search(r'defaultTestDatabaseURL = "([^"]+)"',(r/'candidate/server/cmd/migrate/migrate_concurrent_test.go').read_text())[1].rsplit('/',1)[0]+'/postgres?sslmode=disable'
env=dict(os.environ,DATABASE_URL=dburl)
q="SELECT current_database(), version();"
p=subprocess.run([str(e/'dbprobe.exe')],input=q.encode(),env=env,capture_output=True,check=True)
(e/'postgres-version.json').write_bytes(p.stdout)
q="SELECT datname FROM pg_database WHERE datname LIKE 'tes85_p0_r7_tes107%';"
p=subprocess.run([str(e/'dbprobe.exe')],input=q.encode(),env=env,capture_output=True,check=True)
(e/'database-cleanup-check.json').write_bytes(p.stdout)
assert json.loads(p.stdout)==[], 'owned test databases remain'
print('All owned test databases absent')
