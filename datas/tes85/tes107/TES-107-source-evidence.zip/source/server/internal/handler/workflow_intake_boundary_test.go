package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/multica-ai/multica/server/internal/testutil"
)

func TestWorkflowIntakeControlBoundary(t *testing.T) {
	cleanupWorkflowTemplates(t)
	cleanupWorkflowRuns(t)
	withWorkflowEngineForTest(t)
	tpl := seededBugFixTemplate(t)
	counts := func() string {
		var out string
		err := testPool.QueryRow(context.Background(), `SELECT jsonb_build_array(
			(SELECT count(*) FROM issue WHERE workspace_id=$1),
			(SELECT count(*) FROM workflow_run WHERE workspace_id=$1),
			(SELECT count(*) FROM workflow_step_instance WHERE workspace_id=$1),
			(SELECT count(*) FROM workflow_event WHERE workspace_id=$1),
			(SELECT count(*) FROM agent_task_queue t JOIN agent a ON a.id=t.agent_id WHERE a.workspace_id=$1),
			(SELECT count(*) FROM issue_subscriber s JOIN issue i ON i.id=s.issue_id WHERE i.workspace_id=$1)
		)::text`, testWorkspaceID).Scan(&out)
		if err != nil {
			t.Fatal(err)
		}
		return out
	}
	post := func(t *testing.T, fields string) *testutil.Response {
		t.Helper()
		body := fmt.Sprintf(`{"source":"tes105","event_id":%q,"template_key":%q,"title":"Boundary","description":"Control validation",%s}`, t.Name(), tpl.Key, fields)
		req := testutil.JSONRequest("POST", "/api/workspaces/"+testWorkspaceID+"/workflow-intake", body)
		testutil.WithHeaders(req, "X-User-ID", testUserID, "X-Workspace-ID", testWorkspaceID)
		return testutil.Call(t, testHandler.WorkflowIntake, withURLParam(req, "id", testWorkspaceID))
	}
	for _, key := range []string{"callback_destination_id", "input_instance_id", "input_instance_revision", "input_source", "execution_mode", "debug_session_id", "template_version_id"} {
		for _, variant := range []string{key, strings.ToUpper(key), strings.ToUpper(key[:1]) + key[1:], strings.Replace(key, "s", "ſ", 1)} {
			for _, value := range []string{`"00000000-0000-0000-0000-000000000001"`, `" "`, `false`, `1`, `{}`, `[]`} {
				for _, fields := range []string{
					fmt.Sprintf(`%q:%s`, variant, value),
					fmt.Sprintf(`%q:%s,%q:null`, variant, value, variant),
					fmt.Sprintf(`%q:%s,%q:""`, variant, value, key),
					fmt.Sprintf(`%q:null,%q:%s`, key, variant, value),
				} {
					t.Run(fields, func(t *testing.T) {
						before := counts()
						response := post(t, fields)
						if after := counts(); after != before {
							t.Errorf("rejected intake wrote business rows: %s -> %s", before, after)
						}
						response.Want(400)
					})
				}
			}
		}
	}
	// Escaped JSON names are decoded before matching; nested payload is data.
	t.Run("escaped-key", func(t *testing.T) {
		before := counts()
		response := post(t, `"\u0043ALLBACK_DESTINATION_ID":"x","CALLBACK_DESTINATION_ID":null`)
		if after := counts(); after != before {
			t.Errorf("escaped control wrote rows: %s -> %s", before, after)
		}
		response.Want(400)
	})
	t.Run("empty-controls-payload-and-replay", func(t *testing.T) {
		fields := `"CALLBACK_DESTINATION_ID":null,"callback_destination_id":"","input_source":null,"payload":{"CALLBACK_DESTINATION_ID":"data","execution_mode":"data"}`
		var first, replay WorkflowIntakeResponse
		post(t, fields).Want(201).JSON(&first)
		before := counts()
		post(t, fields).Want(200).JSON(&replay)
		if replay.WorkflowRunID != first.WorkflowRunID || counts() != before {
			t.Fatal("replay changed receipt or wrote business rows")
		}
		run := getWorkflowRunForTest(t, first.WorkflowRunID)
		var input map[string]any
		if err := json.Unmarshal(run.Input, &input); err != nil {
			t.Fatal(err)
		}
		if input["CALLBACK_DESTINATION_ID"] != "data" || input["execution_mode"] != "data" {
			t.Fatalf("nested payload changed: %s", run.Input)
		}
	})
}
