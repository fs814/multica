param(
    [Parameter(Mandatory=$true)][ValidateSet('InitServer','StartDaemon','Snapshot','Cancel','StopDaemon','RestartServer','StopServer','Stop')][string]$Action,
    [Parameter(Mandatory=$true)][ValidatePattern('^tes107-operator-[a-zA-Z0-9-]+$')][string]$Profile,
    [int]$Port=18087,
    [string]$IssueId
)
$ErrorActionPreference='Stop'
$expected='4fc4d1ff2e9ab0688de33732f6c682ff6209cb64'
foreach ($key in @('MULTICA_AGENT_ID','MULTICA_TASK_ID','MULTICA_DAEMON_PORT','MULTICA_TASK_CONFIG_ROOT','MULTICA_TOKEN','MULTICA_SERVER_URL','MULTICA_WORKSPACE_ID')) {
    if ([Environment]::GetEnvironmentVariable($key)) { throw "Independent operator shell required; inherited $key is present. Do not remove task identity to bypass this check." }
}
$cli=Join-Path $PSScriptRoot 'bin/multica.exe'
$server=Join-Path $PSScriptRoot 'bin/server.exe'
$migrate=Join-Path $PSScriptRoot 'bin/migrate.exe'
$statePath=Join-Path $PSScriptRoot ($Profile+'.json')
$logs=Join-Path $PSScriptRoot ($Profile+'-logs')
function Save-State { [IO.File]::WriteAllText($statePath,($script:state | ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false)) }
function Invoke-Cli([string[]]$Arguments) {
    $result=& $cli --profile $Profile @Arguments
    if ($LASTEXITCODE -ne 0) { throw 'Candidate CLI command failed; preserve its local error, do not retry with another identity.' }
    return $result
}
function Assert-Free([int]$Number) {
    if (Get-NetTCPConnection -State Listen -LocalPort $Number -ErrorAction SilentlyContinue) { throw "Port $Number is occupied; choose a new profile/port, never stop its owner." }
}
function Read-Daemon { return ((Invoke-Cli @('daemon','status','--output','json')) -join "`n" | ConvertFrom-Json) }
function Assert-OwnedDaemon($status) {
    if ($status.profile -ne $Profile -or $status.daemon_id -ne $script:state.daemon_id -or $status.server_url.TrimEnd('/') -ne $script:state.server_url) { throw 'Daemon identity mismatch' }
    if ($status.pid -eq $script:state.protected_pid) { throw 'Refusing protected host daemon' }
}
function Start-OwnedServer {
    if (-not $env:DATABASE_URL -or ([uri]$env:DATABASE_URL).AbsolutePath.Trim('/') -ne $script:state.database) { throw 'Restore the same dedicated DATABASE_URL locally first' }
    Assert-Free $script:state.port
    $env:PORT=[string]$script:state.port
    $process=Start-Process -FilePath $server -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $logs 'server.stdout.log') -RedirectStandardError (Join-Path $logs 'server.stderr.log')
    $script:state.server_pid=$process.Id
    $script:state.server_started=$process.StartTime.ToUniversalTime().ToString('o')
    Save-State
    # Readiness is checked through the product health route; no authenticated API bypass.
    for ($attempt=0; $attempt -lt 30; $attempt++) {
        try { $health=Invoke-RestMethod ($script:state.server_url+'/health'); if ($health.commit -eq $expected -and $health.pid -eq $process.Id) { return } } catch {}
        if ($process.HasExited) { throw 'Isolated server exited; inspect local logs' }
        Start-Sleep -Seconds 1
    }
    throw 'Server health did not prove the fixed candidate; recorded PID remains available for cleanup'
}
function Stop-OwnedServer {
    $process=Get-Process -Id $script:state.server_pid -ErrorAction SilentlyContinue
    if ($process) {
        if ($process.StartTime.ToUniversalTime().ToString('o') -ne $script:state.server_started -or $process.Path -ne $server) { throw 'Server PID ownership changed' }
        if ($process.Id -eq $script:state.protected_pid) { throw 'Protected host daemon PID' }
        Stop-Process -Id $process.Id
        $process.WaitForExit(10000) | Out-Null
    }
}
if ($Action -eq 'InitServer') {
    $packageRoot=(Resolve-Path -LiteralPath $PSScriptRoot).Path.TrimEnd('\')+'\'
    foreach ($line in Get-Content (Join-Path $PSScriptRoot 'WINDOWS-MANIFEST.sha256')) {
        $parts=$line -split '  ',2
        if ($parts.Count -ne 2 -or [IO.Path]::IsPathRooted($parts[1])) { throw 'Unsafe package manifest entry' }
        $file=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $parts[1])).Path
        if (-not $file.StartsWith($packageRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest path escapes package' }
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $parts[0]) { throw 'Package hash mismatch' }
    }
    if (Test-Path -LiteralPath $statePath) { throw 'State already exists' }
    if (-not $env:DATABASE_URL) { throw 'Provide a new dedicated DATABASE_URL in this human shell' }
    $dbUri=[uri]$env:DATABASE_URL
    $db=$dbUri.AbsolutePath.Trim('/')
    if ($dbUri.Host -notin @('localhost','127.0.0.1') -or $db -notmatch '^tes107_operator_[a-z0-9_]+$') { throw 'Local disposable tes107_operator_* database required' }
    $profileDir=Join-Path ([Environment]::GetFolderPath('UserProfile')) ('.multica/profiles/'+$Profile)
    if (Test-Path -LiteralPath $profileDir) { throw 'Profile already exists; choose a fresh name' }
    $healthPort=19515+(([Text.Encoding]::UTF8.GetBytes($Profile) | Measure-Object -Sum).Sum % 1000)
    if ($Port -eq $healthPort) { throw 'Server and daemon ports collide' }
    Assert-Free $Port; Assert-Free $healthPort
    New-Item -ItemType Directory -Path $logs | Out-Null
    # Record a host daemon if one exists. This does not stop or reconfigure it.
    $hostStatus=& $cli daemon status --output json
    $protectedPid=0
    if ($LASTEXITCODE -eq 0) { try { $protectedPid=($hostStatus | ConvertFrom-Json).pid } catch {} }
    $script:state=@{profile=$Profile;port=$Port;health_port=$healthPort;server_url="http://127.0.0.1:$Port";database=$db;daemon_id=[guid]::NewGuid().ToString();protected_pid=$protectedPid;server_pid=0;server_started=''}
    Save-State
    Push-Location $PSScriptRoot
    try { & $migrate up *> (Join-Path $logs 'migrate.log'); $migrationExit=$LASTEXITCODE } finally { Pop-Location }
    if ($migrationExit -ne 0) { throw 'Dedicated database migration failed' }
    Invoke-Cli @('config','set','server_url',$script:state.server_url)
    Invoke-Cli @('config','set','workspaces_root',(Join-Path $PSScriptRoot ($Profile+'-workspaces')))
    Start-OwnedServer
    Write-Output 'Isolated server ready. Login interactively with this server-issued member PAT; then run StartDaemon.'
    exit
}
$script:state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
switch ($Action) {
    StartDaemon {
        Assert-Free $script:state.health_port
        Invoke-Cli @('daemon','start','--daemon-id',$script:state.daemon_id,'--device-name',$Profile,'--no-auto-update','--no-auto-reload','--max-concurrent-tasks','1')
        $status=Read-Daemon; Assert-OwnedDaemon $status
        $status | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $logs 'daemon-start.json') -Encoding UTF8
    }
    Snapshot {
        $stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
        $status=Read-Daemon; Assert-OwnedDaemon $status
        $status | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $logs ($stamp+'-daemon.json')) -Encoding UTF8
        if ($IssueId) { Invoke-Cli @('issue','get',$IssueId,'--output','json') | Set-Content (Join-Path $logs ($stamp+'-issue.json')) -Encoding UTF8; Invoke-Cli @('issue','runs',$IssueId,'--output','json') | Set-Content (Join-Path $logs ($stamp+'-runs.json')) -Encoding UTF8 }
        Invoke-Cli @('daemon','logs','--lines','200') | Set-Content (Join-Path $logs ($stamp+'-daemon.log')) -Encoding UTF8
        # No command lines/environment values are collected.
        Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate | ConvertTo-Json -Depth 3 | Set-Content (Join-Path $logs ($stamp+'-processes.json')) -Encoding UTF8
    }
    Cancel { if (-not $IssueId) { throw 'Workflow-bound IssueId required' }; Invoke-Cli @('issue','status',$IssueId,'cancelled','--no-start','--output','json') | Set-Content (Join-Path $logs 'cancel.json') -Encoding UTF8 }
    StopDaemon { $status=Read-Daemon; Assert-OwnedDaemon $status; Invoke-Cli @('daemon','stop') }
    RestartServer { Stop-OwnedServer; Start-OwnedServer }
    StopServer { Stop-OwnedServer }
    Stop { $status=Read-Daemon; Assert-OwnedDaemon $status; Invoke-Cli @('daemon','stop'); Stop-OwnedServer; Write-Output 'Recorded services stopped. Database/profile deletion remains a manual exact-target cleanup.' }
}
