from pathlib import Path
import os, re, subprocess, json, datetime, shutil
root=Path(__file__).resolve().parent
candidate=root/'candidate'; evidence=root/'evidence'; server=candidate/'server'
url=re.search(r'defaultTestDatabaseURL = "([^"]+)"',(server/'cmd/migrate/migrate_concurrent_test.go').read_text())[1]
database='tes85_p0_r7_tes107_full_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
def db_env(name): return dict(os.environ,DATABASE_URL=url.rsplit('/',1)[0]+'/'+name+'?sslmode=disable')
def sql(q):
    p=subprocess.run([str(evidence/'dbprobe.exe'),'exec'],input=q.encode(),env=db_env('postgres'),capture_output=True)
    if p.returncode: raise RuntimeError('database administration failed')
def run(name,args,env):
    print(name,'running',flush=True)
    with (evidence/(name+'.log')).open('wb') as f:
        p=subprocess.run(args,cwd=server,env=env,stdout=f,stderr=subprocess.STDOUT)
    events=[]
    for line in (evidence/(name+'.log')).read_text(errors='replace').splitlines():
        try: events.append(json.loads(line))
        except ValueError: pass
    result={'command':args,'exit':p.returncode,'database':database,'packages':{}}
    for pkg in sorted({x.get('Package','') for x in events}):
        result['packages'][pkg]={a:sum(x.get('Package')==pkg and x.get('Action')==a and bool(x.get('Test')) and '/' not in x['Test'] for x in events) for a in ['pass','fail','skip']}
    result['failures']=[x for x in events if x.get('Action')=='fail']
    result['skips']=[x for x in events if x.get('Action')=='skip']
    (evidence/(name+'.json')).write_text(json.dumps(result,indent=2))
    print(name,'exit',p.returncode,flush=True)
    return p.returncode
owned=False
try:
    sql('CREATE DATABASE "'+database+'"');owned=True
    env=db_env(database)
    # Keep identity markers; isolate Windows profile writes without borrowing owner config.
    profile=evidence/'test-userprofile';profile.mkdir(exist_ok=True)
    for key in ['GOPATH','GOCACHE']:
        env[key]=subprocess.check_output(['go','env',key],cwd=server,text=True).strip()
    env['USERPROFILE']=str(profile)
    env['MULTICA_TASK_CONFIG_ROOT']=str(profile/'task-config')
    if run('standard-migrate',[str(evidence/'migrate-bootstrap.exe'),'up'],env):raise RuntimeError('migration failed')
    guard=evidence/'agent-guard';guard.mkdir(exist_ok=True)
    source=guard/'guard.go'
    source.write_text('''package main
import("os";"path/filepath")
func main(){f,e:=os.OpenFile(os.Getenv("MULTICA_AGENT_CLI_GUARD_MARKER"),os.O_CREATE|os.O_WRONLY|os.O_APPEND,0600);if e==nil{f.WriteString(filepath.Base(os.Args[0])+" [arguments redacted]\\n");f.Close()};os.Exit(126)}
''')
    subprocess.run(['go','build','-o',str(guard/'guard.exe'),str(source)],cwd=server,check=True)
    for name in (candidate/'scripts/agent-cli-command-names.txt').read_text().splitlines():
        if name and not name.startswith('#'):shutil.copyfile(guard/'guard.exe',guard/(name+'.exe'))
    marker=evidence/'agent-guard-invocations.log'
    env.update(PATH=str(guard)+os.pathsep+env['PATH'],MULTICA_AGENT_CLI_GUARD_MARKER=str(marker))
    packages=subprocess.check_output(['go','list','./...'],cwd=server,env=env,text=True).splitlines()
    regular=[p for p in packages if '/pkg/agent' not in p]
    for race in [False,True]:
        label='race' if race else 'standard'
        args=['go','test']+(['-race'] if race else [])+['-count=1','-json','-timeout=5m']
        run(label+'-regular',args+regular,env)
        run(label+'-agent',args+['-p','2','-parallel','2','./pkg/agent/...'],env)
    (evidence/'agent-guard-result.json').write_text(json.dumps({'invocations':marker.read_text() if marker.exists() else '', 'guard':'Windows executable sentinels for every repository agent command name'}))
finally:
    if owned:
        sql('DROP DATABASE "'+database+'"')
        (evidence/'standard-database.json').write_text(json.dumps({'database':database,'created':True,'dropped':True}))
        print('database dropped',database,flush=True)
