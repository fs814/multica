TES-107 external Windows acceptance (NOT EXECUTED)

Candidate: 4fc4d1ff2e9ab0688de33732f6c682ff6209cb64. apply_allowed=false.
This packet is an operator procedure, not evidence of a successful native run.
Do not use the eight archived workflows, a shared daemon, production credentials,
or production databases. Do not publish templates or perform a service cutover.

Required external inputs

- An independent human-operated Windows shell, outside any managed task. The
  supplied script rejects task identity markers; never remove markers to make it run.
- A newly created empty local database named tes107_operator_<unique suffix>,
  PostgreSQL with the extensions required by the unchanged migrations. Supply its
  connection through DATABASE_URL locally; do not attach the value or profile config.
- A legitimate member of this isolated server, an isolated workspace, and a PAT
  issued by this server to that member. Login prompts for it; no borrowed tokens.
  The isolated instance's normal UI/account provisioning must be available first.
- An operator-approved test runtime/agent (any real-agent cost separately approved),
  belonging ONLY to the isolated server. Do not use a runtime of the host workspace.
- For the workflow-specific scenario, a pre-existing synthetic published fixture
  on the isolated database with a running workflow-bound issue. Record template,
  version, run, step, issue and task IDs. This candidate has no workflow CLI command;
  the operator must prepare the fixture through the existing authorized UI. The
  packet neither publishes templates nor synthesizes credentials/database actors.
  Without this input the ordinary CLI task scenario is executable but does NOT
  prove workflow cancellation/reconciliation. Keep that row NOT EXECUTED.

Extract the binary packet and source/evidence packet side by side. Verify the
external SHA256SUMS and every binary hash in CANDIDATE.json. Put bin/ next to the
operator scripts. Start PowerShell in a new dedicated test directory and execute:

```powershell
$profileName = 'tes107-operator-' + (Get-Date -Format 'yyyyMMddHHmmss')
# DATABASE_URL must already point at the operator-created disposable database.
& ./Operator.ps1 InitServer -Profile $profileName -Port 18087
& ./bin/multica.exe --profile $profileName login --token
& ./bin/multica.exe --profile $profileName workspace list --output json
# Choose only the isolated workspace, then persist it:
& ./bin/multica.exe --profile $profileName config set workspace_id <workspace-uuid>
& ./Operator.ps1 StartDaemon -Profile $profileName
& ./bin/multica.exe --profile $profileName runtime list --output json
& ./bin/multica.exe --profile $profileName agent create --name TES107-Probe --runtime-id <isolated-runtime-uuid> --permission-mode private --instructions 'Run only the operator-provided HoldTree.ps1 at its absolute path as a blocking command. Do not access accounts, repositories, or network. Wait until cancellation.' --output json
& ./bin/multica.exe --profile $profileName issue create --title TES107-claim-cancel --description-file ./probe-task.md --assignee-id <probe-agent-uuid> --status todo --output json
& ./Operator.ps1 Snapshot -Profile $profileName -IssueId <issue-uuid>
```

Create probe-task.md as UTF-8 in the test directory. Its only task is to execute
`powershell.exe -NoProfile -File <absolute HoldTree.ps1> -OutputDir <absolute probe dir>`
and remain in that foreground command. Both paths must be within this dedicated
operator directory. The probe lasts at most ten minutes and records parent/child
PIDs and creation times. Record the provider process PID from the daemon's process
tree too; do not collect command lines (they may contain credentials).

Acceptance sequence (record actual timestamps and IDs; no inferred PASS)

1. Save CLI version, server /health commit/PID, daemon status profile/daemon ID/PID/
   server URL, and runtime list. These must match the fixed binary and isolation
   ledger. Profile health port is derived from its UTF-8 byte sum; the launcher
   checks it is free and different from the server port before starting.
2. Claim: Snapshot until the issue run is actually running on the isolated runtime.
   Mere issue creation or queued/dispatched state is insufficient. Confirm parent,
   child, provider PIDs and creation times exist before cancellation.
3. Ordinary issue: use `multica.exe --profile <profile> issue cancel-task <run-id> --issue <issue-uuid> --output json` if ordinary issue
   status does not cancel its task; do not treat issue status alone as process proof.
   For the workflow-bound fixture use the concrete command:
   `Operator.ps1 Cancel -Profile <profile> -IssueId <workflow-bound-issue-uuid>`.
   It runs `issue status <id> cancelled --no-start`; save response, task terminal
   state, workflow run/step/event state through the isolated UI, and Snapshot.
4. Within the agreed cancellation deadline (record it, e.g. 30 seconds), all three
   recorded processes must be gone, verified by PID AND creation time. Record each
   observation and exit latency; PID reuse is not a live original process.
5. Stop/restart the isolated SERVER with RestartServer after cancellation, retaining
   the same database/profile. Confirm no duplicate submission/next-step activation
   and that cancellation remains terminal. Repeat with an in-flight fixture: stop
   only the isolated daemon after claim, cancel the workflow-bound issue while it
   is offline, restart via StartDaemon, and inspect reconciler recovery/no re-claim.
   Failure to stop a task is NOT automatically induced by stopping the daemon;
   record the real states. In-process TaskService failure injection is covered by
   TestR5CancelledRunRecoversTaskServiceFailureAfterRestart, not by this native run.
6. Snapshot after each phase. `issue run-messages <task-id> --output json` and
   `daemon logs --lines 200` provide CLI-only log collection. Keep local raw logs
   private; sanitize token/password/Authorization values, personal paths and prompts
   before attaching. Never attach the profile config, DATABASE_URL or env dumps.
7. Stop uses only the recorded profile and verified process identities. Before any
   manual termination compare the target against `multica daemon status --output
   json` for the host and every recorded protected PID. Never kill by executable
   name. Drop ONLY the exact operator-created database after saving evidence;
   remove ONLY the dedicated operator directory/profile after resolving absolute
   paths and checking that no host profile/workspace is selected. Retain cleanup
   receipts. Database/profile deletion is deliberately manual, not a broad script.

The native result table must separately record claim, workflow cancellation,
TaskService dispatch, parent exit, child exit, provider exit, server restart,
offline-daemon recovery, cleanup, failures and NOT EXECUTED inputs. Ordinary-task
claim/cancel and a service test are not substitutes for workflow-native evidence.
Mac/Linux require their own matching native builds and the same observations;
Windows builds/race compilation do not satisfy those rows.
