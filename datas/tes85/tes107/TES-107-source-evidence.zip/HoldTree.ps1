param([Parameter(Mandatory=$true)][string]$OutputDir, [switch]$Child)
$ErrorActionPreference = 'Stop'
$deadline = (Get-Date).AddMinutes(10)
if ($Child) {
    while ((Get-Date) -lt $deadline) { Start-Sleep -Seconds 1 }
    exit
}
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$childProcess = Start-Process powershell.exe -ArgumentList @('-NoProfile','-File',('"'+$PSCommandPath+'"'),'-OutputDir',('"'+$OutputDir+'"'),'-Child') -WindowStyle Hidden -PassThru
$parentProcess = Get-Process -Id $PID
$handles = @{
    parent = @{pid=$PID; started=$parentProcess.StartTime.ToUniversalTime().ToString('o')}
    child = @{pid=$childProcess.Id; started=$childProcess.StartTime.ToUniversalTime().ToString('o')}
    deadline = $deadline.ToUniversalTime().ToString('o')
}
[IO.File]::WriteAllText((Join-Path $OutputDir 'process-handles.json'),($handles | ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
try {
    while ((Get-Date) -lt $deadline) { Start-Sleep -Seconds 1 }
} finally {
    $current = Get-Process -Id $childProcess.Id -ErrorAction SilentlyContinue
    if ($current -and $current.StartTime -eq $childProcess.StartTime) { Stop-Process -Id $childProcess.Id }
}
