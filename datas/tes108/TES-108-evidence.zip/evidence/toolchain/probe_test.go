package probe
import "testing"
func TestRaceProbe(t *testing.T){ c:=make(chan int);go func(){c<-42}();if <-c!=42{t.Fatal("bad value")} }
