from pathlib import Path
import subprocess,json,os,hashlib
root=Path(__file__).resolve().parent
repo=root/'candidate-lf';out=root/'lineendings';out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','ls-files','server/internal/service/builtin_skills','server/internal/service/builtin_skills_legacy'],cwd=repo,text=True).splitlines()
replacement={};manifest=[]
for name in paths:
    raw=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo)
    p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    replacement[str(repo/name)]=str(p)
    manifest.append({'path':name,'blob_sha256':hashlib.sha256(raw).hexdigest(),'checkout_sha256':hashlib.sha256((repo/name).read_bytes()).hexdigest()})
overlay=out/'overlay.json';overlay.write_text(json.dumps({'Replace':replacement}))
env=dict(os.environ)
env.update(json.loads(subprocess.check_output(['go','env','-json','GOPATH','GOCACHE','GOMODCACHE'],cwd=repo/'server')))
for key in ['HOME','USERPROFILE','APPDATA','LOCALAPPDATA','MULTICA_TASK_CONFIG_ROOT']:
    p=out/key;p.mkdir(exist_ok=True);env[key]=str(p)
env.update(MULTICA_TOKEN='tes108-invalid-test-token',MULTICA_SERVER_URL='http://127.0.0.1:0',DATABASE_URL='postgres://unused:unused@127.0.0.1:0/tes108_unreachable')
args=['go','test','-overlay',str(overlay),'./internal/service','-run','^Test(BuiltinSkillsConformToTemplate|BuiltinSkillsFrontmatterIsStrictYAML|LegacyRedirectsFollowTheDaemonsBrief|PlatformSkillDescriptionNamesEveryDomain)$','-count=1','-json']
with (out/'lf-skills.log').open('wb') as f:p=subprocess.run(args,cwd=repo/'server',env=env,stdout=f,stderr=subprocess.STDOUT)
(out/'results.json').write_text(json.dumps({'exit':p.returncode,'command':args,'manifest':manifest},indent=2));print('LF blob overlay exit',p.returncode)
