from pathlib import Path
import os, re, subprocess, json, datetime, hashlib, shutil, socket, sys

root = Path(__file__).resolve().parent
repo = root / ('final-candidate' if '--final' in sys.argv else ('candidate-lf' if '--corrected' in sys.argv else 'candidate'))
server = repo / 'server'
label = sys.argv[1] if len(sys.argv) > 1 else 'baseline'
out = root / label
out.mkdir(exist_ok=True)
env = dict(os.environ)
env.update(json.loads(subprocess.check_output(['go', 'env', '-json', 'GOPATH', 'GOCACHE', 'GOMODCACHE'], cwd=server)))
for key, leaf in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/appdata'),('LOCALAPPDATA','home/local'),('XDG_CONFIG_HOME','home/config'),('XDG_CACHE_HOME','home/cache'),('MULTICA_CONFIG_DIR','home/multica'),('MULTICA_TASK_CONFIG_ROOT','home/task'),('TEMP','tmp'),('TMP','tmp')]:
    p = out / leaf
    if any(x in sys.argv for x in ['--corrected','--final']) and key in ['TEMP','TMP']:
        p = Path(os.environ['TEMP']) / ('t108-' + label)
    p.mkdir(parents=True, exist_ok=True)
    env[key] = str(p)
# Preserve task identity markers. Never pass a usable credential or live daemon
# endpoint into the suite; reserve loopback ports owned by this harness.
ports = []
for _ in range(2):
    s = socket.socket(); s.bind(('127.0.0.1',0)); ports.append(s)
env['MULTICA_SERVER_URL'] = 'http://127.0.0.1:' + str(ports[0].getsockname()[1])
env['MULTICA_DAEMON_PORT'] = str(ports[1].getsockname()[1])
env['MULTICA_TOKEN'] = 'tes108-invalid-test-token'
env['MULTICA_RUN_REAL_AGENT_SMOKE'] = '0'
env['MULTICA_PROFILE'] = 'tes108-isolated'
if any(x in sys.argv for x in ['--corrected','--final']):
    env['PATH'] = str(Path(shutil.which('gcc')).parent) + os.pathsep + env['PATH']
if '--final' in sys.argv:
    (Path(env['HOME'])/'.gitconfig').write_text('[core]\n\tlongpaths = true\n\tautocrlf = false\n', encoding='utf-8')
url = re.search(r'defaultTestDatabaseURL = "([^"]+)"', (server/'cmd/migrate/migrate_concurrent_test.go').read_text())[1]
db = 'tes85_p0_r7_tes108_' + label.replace('-','_') + '_' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
env['DATABASE_URL'] = url.rsplit('/',1)[0] + '/' + db + '?sslmode=disable'
summary = {'sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(), 'apply_allowed':False,'database':db,'ports':[s.getsockname()[1] for s in ports], 'runs':{}}
host = Path(os.environ['USERPROFILE']) / '.multica/config.json'
def stamp():
    if not host.exists(): return None
    s=host.stat(); return [s.st_size,s.st_mtime_ns,hashlib.sha256(host.read_bytes()).hexdigest()]
before=stamp()
def save(): (out/'results.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
def run(name,args,cwd=server,e=None):
    print(name,'running',flush=True)
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.log')).open('wb') as f:
        p=subprocess.run(args,cwd=cwd,env=e or env,stdout=f,stderr=subprocess.STDOUT)
    events=[]
    for line in (out/(name+'.log')).read_text(encoding='utf-8',errors='replace').splitlines():
        try:
            x=json.loads(line)
            if isinstance(x,dict):events.append(x)
        except ValueError:pass
    started={(x.get('Package'),x.get('Test')) for x in events if x.get('Action')=='run'}
    ended={(x.get('Package'),x.get('Test')) for x in events if x.get('Action') in ['pass','fail','skip']}
    result={'command':args,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,
        'top':{a:sum(x.get('Action')==a and bool(x.get('Test')) and '/' not in x['Test'] for x in events) for a in ['pass','fail','skip']},
        'unfinished':sorted([list(x) for x in started-ended]),
        'failures':[x for x in events if x.get('Action') in ['fail','build-fail']],
        'skips':[x for x in events if x.get('Action')=='skip']}
    summary['runs'][name]=result;save()
    print(name,'exit',p.returncode,result['top'],'unfinished',len(result['unfinished']),flush=True)
    return p.returncode
def sql(q):
    e=dict(env,DATABASE_URL=url.rsplit('/',1)[0]+'/postgres?sslmode=disable')
    p=subprocess.run([str(out/'dbprobe.exe'),'exec'],input=q.encode(),env=e,capture_output=True)
    if p.returncode:raise RuntimeError('DB administration failed: '+p.stderr.decode(errors='replace'))
owned=False
try:
    assert run('build-dbprobe',['go','build','-o',str(out/'dbprobe.exe'),str(root/'inputs/107/source/dbprobe.go')])==0
    assert run('build-migrate',['go','build','-o',str(out/'migrate.exe'),'./cmd/migrate'])==0
    sql('CREATE DATABASE "'+db+'"');owned=True
    assert run('migrate',[str(out/'migrate.exe'),'up'])==0
    guard=out/'guard';guard.mkdir(exist_ok=True)
    source=guard/'guard.go'
    source.write_text('package main\nimport("os";"path/filepath")\nfunc main(){f,e:=os.OpenFile(os.Getenv("MULTICA_AGENT_CLI_GUARD_MARKER"),os.O_CREATE|os.O_WRONLY|os.O_APPEND,0600);if e==nil{f.WriteString(filepath.Base(os.Args[0])+" [arguments redacted]\\n");f.Close()};os.Exit(126)}\n')
    assert run('build-guard',['go','build','-o',str(guard/'guard.exe'),str(source)])==0
    for name in (repo/'scripts/agent-cli-command-names.txt').read_text().splitlines():
        if name and not name.startswith('#'):shutil.copyfile(guard/'guard.exe',guard/(name+'.exe'))
    env['PATH']=str(guard)+os.pathsep+env['PATH']
    env['MULTICA_AGENT_CLI_GUARD_MARKER']=str(out/'guard-invocations.log')
    run('build',['go','build','./...'])
    run('vet',['go','vet','./...'])
    run('handler',['go','test','./internal/handler','-count=1','-json','-timeout=5m'])
    packages=subprocess.check_output(['go','list','./...'],cwd=server,env=env,text=True).splitlines()
    regular=[p for p in packages if '/pkg/agent' not in p]
    for race in [False,True]:
        prefix='race' if race else 'standard'
        args=['go','test']+(['-race'] if race else [])+['-count=1','-json','-timeout=5m']
        run(prefix+'-regular',args+regular)
        run(prefix+'-agent',args+['-p','2','-parallel','2','./pkg/agent/...'])
finally:
    if owned:
        sql('DROP DATABASE "'+db+'"');summary['database_dropped']=True
    summary['host_config_unchanged']=before==stamp()
    summary['identity_ids_preserved']=all(env.get(k)==os.environ.get(k) for k in ['MULTICA_TASK_ID','MULTICA_AGENT_ID'])
    save()
    for s in ports:s.close()
    print('cleanup',summary.get('database_dropped'),'host_config_unchanged',summary['host_config_unchanged'],flush=True)
