from pathlib import Path
import os,subprocess,json,datetime
root=Path(__file__).resolve().parent
out=root/'diagnostic-agent';out.mkdir(exist_ok=True)
env=dict(os.environ)
env.update(json.loads(subprocess.check_output(['go','env','-json','GOPATH','GOCACHE','GOMODCACHE'],cwd=root/'candidate-lf/server')))
env['GOTOOLCHAIN']='go1.26.6'
for key in ['HOME','USERPROFILE','APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_CACHE_HOME','MULTICA_TASK_CONFIG_ROOT','MULTICA_CONFIG_DIR','MULTICA_TASK_WORKSPACES_ROOT']:
    p=out/key;p.mkdir(exist_ok=True);env[key]=str(p)
tmp=Path(os.environ['TEMP'])/'t108-diag';tmp.mkdir(exist_ok=True)
env.update(TEMP=str(tmp),TMP=str(tmp),PATH=str(root/'corrected/guard')+os.pathsep+'C:/tools/msys64/mingw64/bin'+os.pathsep+env['PATH'],MULTICA_TOKEN='tes108-invalid-test-token',MULTICA_SERVER_URL='http://127.0.0.1:0',MULTICA_DAEMON_PORT='0',MULTICA_RUN_REAL_AGENT_SMOKE='0',MULTICA_AGENT_CLI_GUARD_MARKER=str(out/'guard.log'),DATABASE_URL='postgres://unused:unused@127.0.0.1:0/tes108_unreachable')
results={}
def run(name,repo,args):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.log')).open('wb') as f:
        p=subprocess.run(['go','test','-count=1','-json','-timeout=60s']+args,cwd=repo/'server',env=env,stdout=f,stderr=subprocess.STDOUT)
    results[name]={'exit':p.returncode,'args':args,'start':start}
    (out/'results.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)

run('upstream-agent',root/'upstream',['-p','2','-parallel','2','./pkg/agent/...'])
run('candidate-schema',root/'candidate-lf',['./pkg/agent','-run','^TestCodexOutputSchemaIsAnObjectOnTheWire$'])
