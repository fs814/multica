from pathlib import Path
import json, re, subprocess, collections
root=Path(__file__).resolve().parent
repo=root/'candidate-lf'
base='9d18186e6e8cfa168d6053d33d652e86fadfc12b'
changed=set(subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=repo,text=True).splitlines())
definitions={}
for file in (repo/'server').rglob('*_test.go'):
    for m in re.finditer(r'^func (Test\w+)\(',file.read_text(encoding='utf-8'),re.M):
        definitions[(str(file.parent.relative_to(repo/'server')).replace('\\','/'),m[1])]=str(file.relative_to(repo)).replace('\\','/')
def events(file):
    result=[]
    for line in file.read_text(encoding='utf-8',errors='replace').splitlines():
        try:
            x=json.loads(line)
            if isinstance(x,dict):result.append(x)
        except ValueError:pass
    return result
def category(pkg,test,output):
    text=output.lower()
    if 'data race' in text:return 'race detector finding; inspect stacks'
    if any(s in text for s in ['task-scoped mat_', 'agent execution context', 'inside an agent task','managed agent task','task context','task-config','home\\task','home\\\\task']):return 'managed identity/config isolation; no authorization bypass'
    if pkg.endswith('wecom'):return 'Windows open-file unlink; product portability defect predates candidate'
    if 'frontmatter' in text or test=='TestPlatformSkillDescriptionNamesEveryDomain':return 'CRLF checkout/embedded bytes; compare LF run'
    if any(s in text for s in ['want 0700','want 700','want 0600','want 0644','mode = 0777','mode = 777']):return 'POSIX mode assertion on Windows; security assertion retained'
    if 'could not create leading directories' in text or 'filename too long' in text:return 'Windows path length/Git repository fixture'
    if any(s in text for s in ['dubious ownership','not in a git directory','configure fetch refspec']):return 'Git repository fixture/ownership configuration; not classified as harmless'
    if any(s in text for s in ['executable file not found','not a valid win32','%1 is not a valid','executable not found','no agent cli found','exec format','cannot find the file specified']):return 'Windows executable/fixture path; actual assertion remains failed'
    if 'interface conversion' in text:return 'test panic after HOME-only tilde fixture; USERPROFILE differs'
    if 'access is denied' in text:return 'Windows file replace/access failure; unresolved portability'
    if pkg=='pkg/agent':return 'agent fixture/protocol assertion; see exact output (not blanket environment waiver)'
    if pkg=='internal/realtime':return 'registration timing/assertion; nondeterministic, requires native follow-up'
    if any(s in text for s in ['home','userprofile','.openclaw','config.json']):return 'home/config path expectation; inspect per-test evidence'
    return 'unresolved assertion; requires scoped follow-up'
summary={}
inputs=[('history',root/'inputs/107/source/evidence')]+[(x,root/x) for x in ['baseline','corrected','final']]
for label,folder in inputs:
    if not folder.exists():continue
    for name in ['handler','standard-regular','standard-agent','race-regular','race-agent']:
        file=folder/(name+'.log')
        if not file.exists():continue
        ev=events(file);bytest=collections.defaultdict(list)
        for i,e in enumerate(ev,1):
            if e.get('Action')=='output' and e.get('Test'):
                bytest[(e.get('Package'),e['Test'].split('/')[0])].append(e.get('Output',''))
        failed=[e for e in ev if e.get('Action')=='fail' and e.get('Test') and '/' not in e['Test']]
        rows=[]
        for e in failed:
            pkg=e['Package'].split('/server/')[-1];test=e['Test'];output=''.join(bytest[(e['Package'],test)])
            source=definitions.get((pkg,test))
            rows.append({'package':pkg,'test':test,'category':category(pkg,test,output),'test_source':source,'test_source_changed_from_upstream':source in changed if source else None,'evidence':output})
        started={(e.get('Package'),e.get('Test')) for e in ev if e.get('Action')=='run'}
        ended={(e.get('Package'),e.get('Test')) for e in ev if e.get('Action') in ['pass','fail','skip']}
        item={'top':{a:sum(e.get('Action')==a and bool(e.get('Test')) and '/' not in e['Test'] for e in ev) for a in ['pass','fail','skip']},'package_failures':[e for e in ev if e.get('Action') in ['fail','build-fail'] and not e.get('Test')], 'failed_by_package':dict(collections.Counter(r['package'] for r in rows)), 'categories':dict(collections.Counter(r['category'] for r in rows)), 'unfinished':sorted([list(x) for x in started-ended]),'failures':rows,'skips':[e for e in ev if e.get('Action')=='skip']}
        summary[label+'/'+name]={k:v for k,v in item.items() if k not in ['failures','skips','unfinished','package_failures']}
        summary[label+'/'+name]['unfinished']=len(item['unfinished'])
        summary[label+'/'+name]['build_failures']=sum(e.get('Action')=='build-fail' for e in ev)
        dest=root/'analysis';dest.mkdir(exist_ok=True)
        (dest/(label+'-'+name+'.json')).write_text(json.dumps(item,ensure_ascii=False,indent=2),encoding='utf-8')
        if label!='history' and name.startswith('standard'):
            oldfile=root/'analysis'/('history-'+name+'.json')
            if oldfile.exists():
                old=json.loads(oldfile.read_text(encoding='utf-8'))
                oldset={(r['package'],r['test']) for r in old['failures']};newset={(r['package'],r['test']) for r in rows}
                (dest/(label+'-'+name+'-delta.json')).write_text(json.dumps({'only_history':sorted(oldset-newset),'only_current':sorted(newset-oldset),'both':sorted(oldset&newset)},indent=2))
(root/'analysis/summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
