param([Parameter(Mandatory=$true)][string]$UpstreamRepo)
$ErrorActionPreference = 'Stop'
$candidate = Join-Path $PSScriptRoot 'final-candidate'
$bundle = Join-Path $PSScriptRoot 'inputs/107/source/TES-107-final.bundle'
$expected = '4fc4d1ff2e9ab0688de33732f6c682ff6209cb64'
if (Test-Path -LiteralPath $candidate) { throw 'Use a fresh extraction directory.' }
git clone --shared --no-checkout $UpstreamRepo $candidate
if ($LASTEXITCODE -ne 0) { throw 'Clone failed' }
git -C $candidate config core.autocrlf false
# Match the CRLF working-tree bytes used by the recorded final full-suite run.
# LF embedded-resource diagnostics are separate and do not change that receipt.
git -C $candidate config core.eol crlf
git -C $candidate bundle verify $bundle
if ($LASTEXITCODE -ne 0) { throw 'Missing fixed upstream prerequisite' }
git -C $candidate fetch $bundle refs/heads/tes107-final:refs/heads/tes108-input
if ($LASTEXITCODE -ne 0) { throw 'Bundle import failed' }
git -C $candidate checkout --detach $expected
if ($LASTEXITCODE -ne 0 -or (git -C $candidate rev-parse HEAD) -ne $expected) { throw 'SHA mismatch' }
python (Join-Path $PSScriptRoot 'run.py') final --final
if ($LASTEXITCODE -ne 0) { throw 'Harness or cleanup failed; inspect final logs' }
Write-Output 'Execution complete. Inspect every final/results.json exit and skip count; harness completion is not suite PASS.'
