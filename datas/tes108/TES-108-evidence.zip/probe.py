from pathlib import Path
import os, subprocess, json, hashlib
root=Path(__file__).resolve().parent
out=root/'toolchain';out.mkdir(exist_ok=True)
env=dict(os.environ)
env.update(json.loads(subprocess.check_output(['go','env','-json','GOPATH','GOCACHE','GOMODCACHE'],cwd=root/'candidate/server')))
for key in ['HOME','USERPROFILE','APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_CACHE_HOME','TEMP','TMP']:
    p=out/key;p.mkdir(exist_ok=True);env[key]=str(p)
(out/'go.mod').write_text('module tes108-probe\n\ngo 1.26.6\n')
(out/'probe_test.go').write_text('package probe\nimport "testing"\nfunc TestRaceProbe(t *testing.T){ c:=make(chan int);go func(){c<-42}();if <-c!=42{t.Fatal("bad value")} }\n')
(out/'hello.c').write_text('int main(void) { return 0; }\n')
results={}
for label, e in [('original',env),('mingw-first',dict(env,PATH='C:/tools/msys64/mingw64/bin'+os.pathsep+env['PATH']))]:
    results[label]={}
    for name,args in [('selected-ld',['C:/tools/msys64/mingw64/x86_64-w64-mingw32/bin/ld.exe','--version']),('c-link',['gcc','hello.c','-o',label+'.exe']),('race',['go','test','-race','-count=1','-json','probe_test.go'])]:
        p=subprocess.run(args,cwd=out,env=e,capture_output=True)
        (out/(label+'-'+name+'.log')).write_bytes(p.stdout+p.stderr)
        results[label][name]={'command':args,'exit':p.returncode}
    dlls={}
    for dll in ['libintl-8.dll','libwinpthread-1.dll','zlib1.dll','libzstd.dll','libiconv-2.dll']:
        matches=[]
        for directory in e['PATH'].split(os.pathsep):
            p=Path(directory)/dll
            if p.is_file():matches.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        dlls[dll]=matches
    results[label]['dll_search']=dlls
(out/'results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({k:{n:v for n,v in r.items() if n!='dll_search'} for k,r in results.items()},indent=2))
checks=[]
for relative in ['inputs/107/source/MANIFEST.sha256']:
    manifest=root/relative
    for line in manifest.read_text().splitlines():
        sha,name=line.split('  ',1)
        p=manifest.parent/name
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        checks.append({'file':name,'expected':sha,'actual':actual,'matches':sha.lower()==actual})
(root/'input-manifest-check.json').write_text(json.dumps(checks,indent=2))
assert all(x['matches'] for x in checks)
print('verified manifest entries',len(checks))
