from pathlib import Path
import subprocess, json, hashlib, os, sys, time

root=Path(__file__).resolve().parent
repo=root/'p0'
ev=root/'evidence'
ev.mkdir(exist_ok=True)
pkg=root/'extracted/TES-85-r4-source-evidence'
bins=root/'extracted/TES-85-r4-windows-candidates'
base='9d18186e6e8cfa168d6053d33d652e86fadfc12b'
p0='0ca4c63c0dd02e00c2fdacc9d8c4f480e291f815'
old='e44b6a8d70b826ff368390cab62de5bbffb7167e'
def run(args,cwd=None,env=None,data=None):
    p=subprocess.run(args,cwd=cwd,env=env,input=data,capture_output=True)
    if p.returncode: raise RuntimeError(str(args)+': '+p.stderr.decode(errors='replace')[-2500:])
    return p.stdout
def git(*args): return run(['git',*args],cwd=repo)
def write(name,data): (ev/name).write_text(json.dumps(data,indent=2),encoding='utf-8')
def artifacts():
    out={}
    for name in ['TES-85-r4-source-evidence','TES-85-P0-P1-20260916']:
        path=root/'extracted'/name
        manifest=json.loads((path/'SHA256SUMS.json').read_text())
        bad=[n for n,h in manifest.items() if hashlib.sha256((path/n).read_bytes()).hexdigest()!=h]
        out[name]={'files':len(manifest),'mismatches':bad};assert not bad,bad
    manifest=json.loads((bins/'SHA256SUMS.json').read_text())
    out['binaries']={}
    for n,d in manifest.items():
        actual=hashlib.sha256((bins/n).read_bytes()).hexdigest()
        assert actual==d['sha256'] and (bins/n).stat().st_size==d['size']
        meta=run(['go','version','-m',str(bins/n)]).decode()
        rev=old if n.startswith('old-') else p0 if n.startswith('p0-') else '122a8fd72e1252316aa1939a6ecc44b95212de81'
        assert 'vcs.revision='+rev in meta and 'vcs.modified=false' in meta
        (ev/(n+'.metadata.txt')).write_text(meta)
        out['binaries'][n]={'sha256':actual,'revision':rev,'clean':True}
    scope=json.loads((pkg/'scope.json').read_text())
    actual=git('diff','8e24b7f4afbeac7cc79678288582a94b867a35c1',p0)
    assert actual.replace(b'\r\n',b'\n')==(pkg/'P0-fix.patch').read_bytes().replace(b'\r\n',b'\n')
    assert git('diff','--name-only','8e24b7f4afbeac7cc79678288582a94b867a35c1',p0).decode().splitlines()==scope['p0_delta_paths']
    delta=git('diff','--name-only','361dfb2f2',p0).decode().splitlines()
    assert delta==['server/cmd/migrate/README.md']
    out['P0_patch_matches']=True;out['code_to_final_delta']=delta
    manifest=json.loads((pkg/'evidence/migration-sha256.json').read_text())
    bad=[]
    for n,h in manifest.items():
        raw=git('show',p0+':'+n)
        if h not in [hashlib.sha256(raw).hexdigest(),hashlib.sha256(raw.replace(b'\n',b'\r\n')).hexdigest()]:bad.append(n)
    out['migrations']={'count':len(manifest),'mismatches':bad};assert not bad,bad
    out['archive_commit_available']=subprocess.run(['git','cat-file','-t','1ef4de983ea4f0220a363583f20bef3f24152fcc'],cwd=repo,capture_output=True).returncode==0
    write('artifacts.json',out);print(json.dumps(out,indent=2))

def regressions():
    container=run(['podman','run','-d','--name','tes104-prefix-review','-e','POSTGRES_USER=multica','-e','POSTGRES_PASSWORD=multica','-p','127.0.0.1::5432','docker.io/pgvector/pgvector:pg17']).decode().strip()
    engine=['podman','exec',container]
    names=['tes85_p0_tes104_review','tes85Xp0Xreview0916','tes85Xp0_tes104','tes85_p0Xtes104','tes85p0_tes104','tes85_p0tes104','ordinary_tes104']
    tests={};owned=[]
    try:
        port=run(['podman','port',container,'5432']).decode().strip().rsplit(':',1)[1]
        for _ in range(100):
            ready=subprocess.run(engine+['pg_isready','-U','multica'],capture_output=True)
            if ready.returncode==0:break
            time.sleep(.2)
        else:raise RuntimeError('isolated PostgreSQL not ready')
        for i,name in enumerate(names):
            run(engine+['createdb','-U','multica',name]);owned.append(name)
            env=dict(os.environ,DATABASE_URL=f'postgres://multica:multica@localhost:{port}/{name}?sslmode=disable',TES85_RUN_MIGRATION_TESTS='1')
            env.pop('TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK',None)
            pattern='TestTES85|TestReviewerPreexistingUniqueIndexOwnership|TestReview104' if i==0 else '^TestTES85DatabasePrefixBoundary$|^TestReviewerLiteralDatabasePrefix$' if i==1 else '^TestTES85DatabasePrefixBoundary$'
            p=subprocess.run(['go','test','./cmd/migrate','-run',pattern,'-count=1','-json'],cwd=repo/'server',env=env,capture_output=True)
            (ev/(name+'.jsonl')).write_bytes(p.stdout);(ev/(name+'.stderr.log')).write_bytes(p.stderr)
            events=[json.loads(s) for s in p.stdout.splitlines() if s.startswith(b'{')]
            counts={a:sum(e.get('Action')==a and bool(e.get('Test')) and '/' not in e['Test'] for e in events) for a in ['pass','fail','skip']}
            tests[name]={'exit':p.returncode,**counts};print(name,tests[name],flush=True)
    finally:
        for name in reversed(owned):run(engine+['dropdb','-U','multica',name])
        write('regressions.json',tests);write('regression-cleanup.json',owned)
        run(['podman','rm','-f',container])
        write('prefix-container-cleanup.json',{'id':container,'removed':True})
    assert all(x['exit']==0 and x['skip']==0 for x in tests.values()),tests

if __name__=='__main__':
    {'artifacts':artifacts,'regressions':regressions}[sys.argv[1]]()
