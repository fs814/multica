package main

import "testing"

func TestReviewerPreexistingUniqueIndexOwnership(t *testing.T) {
    pool, ctx := tes85TestDB(t)
    if _, err := pool.Exec(ctx, `CREATE UNIQUE INDEX idx_tes85_workflow_template_id ON workflow_template(id)`); err != nil { t.Fatal(err) }
    var originalOID uint32
    if err := pool.QueryRow(ctx, `SELECT 'idx_tes85_workflow_template_id'::regclass::oid`).Scan(&originalOID); err != nil { t.Fatal(err) }
    if err := tes85Run(t, pool, ctx, "up", tes85KeyNames()...); err != nil { t.Fatal(err) }
    t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK", "1")
    if err := tes85Run(t, pool, ctx, "down", tes85KeyNames()...); err != nil { return }
    var remains bool
    if err := pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM pg_class WHERE oid=$1)`, originalOID).Scan(&remains); err != nil { t.Fatal(err) }
    if !remains { t.Fatal("pre-existing equivalent unique index was adopted as owned and deleted by down") }
}

func TestReviewerLiteralDatabasePrefix(t *testing.T) {
    pool, ctx := tes85TestDB(t)
    t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK", "1")
    var name string
    if err := pool.QueryRow(ctx, "SELECT current_database()").Scan(&name); err != nil { t.Fatal(err) }
    if name != "tes85Xp0Xreview0916" { t.Skip("requires dedicated nonmatching test database") }
    if err := tes85EmptyRollback(ctx, pool); err == nil { t.Fatal("rollback accepted database without literal tes85_p0_ prefix") }
}
