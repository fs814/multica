package main

import (
    "testing"
    "os"
    "path/filepath"
)

func TestReview104UnmarkedCrashAndLegacyMarkers(t *testing.T) {
    for _, table := range tes85PrimaryTables {
        for _, state := range []string{"create_before_comment", "attach_before_ledger", "legacy_v1_index"} {
            t.Run(table+"/"+state,func(t *testing.T) {
                pool,ctx:=tes85TestDB(t)
                index:="254_tes85_"+table+"_id_index"
                apply:=func(name string){
                    b,err:=os.ReadFile(filepath.Join("../../migrations",name+".up.sql"));if err!=nil {t.Fatal(err)}
                    if _,err=pool.Exec(ctx,string(b));err!=nil {t.Fatal(err)}
                }
                apply(index)
                var oid uint32
                if err:=pool.QueryRow(ctx,"SELECT to_regclass($1)::oid","idx_tes85_"+table+"_id").Scan(&oid);err!=nil {t.Fatal(err)}
                if state=="legacy_v1_index" {
                    if _,err:=pool.Exec(ctx,"COMMENT ON INDEX idx_tes85_"+table+"_id IS 'tes85:p0:owned:v1'");err!=nil {t.Fatal(err)}
                }
                if state=="attach_before_ledger" {apply("255_tes85_"+table+"_pkey")}
                if err:=tes85Run(t,pool,ctx,"up",tes85KeyNames()...);err!=nil {t.Fatal(err)}
                var kept bool
                if err:=pool.QueryRow(ctx,"SELECT conindid=$2 AND obj_description(oid,'pg_constraint') IS NULL FROM pg_constraint WHERE conrelid=to_regclass($1) AND contype='p'",table,oid).Scan(&kept);err!=nil || !kept {t.Fatalf("lost provenance/OID: %v %v",kept,err)}
                before:=tes85CatalogState(t,ctx,pool)
                t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK","1")
                if err:=tes85Run(t,pool,ctx,"down",tes85KeyNames()...);err==nil {t.Fatal("accepted unowned down")}
                if tes85CatalogState(t,ctx,pool)!=before {t.Fatal("refusal mutated catalog/ledger")}
            })
        }
    }
}

func TestReview104ExplicitSwitchAndOwnershipLoss(t *testing.T) {
    for _, state:=range []string{"unset", "true", "0", "missing_index_marker", "missing_constraint_marker", "legacy_both"} {
        t.Run(state,func(t *testing.T){
            pool,ctx:=tes85TestDB(t)
            if err:=tes85Run(t,pool,ctx,"up",tes85KeyNames()...);err!=nil {t.Fatal(err)}
            t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK","1")
            var q string
            switch state {
            case "unset":t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK","")
            case "true","0":t.Setenv("TES85_ALLOW_EMPTY_SCHEMA_ROLLBACK",state)
            case "missing_index_marker":q="COMMENT ON INDEX workflow_template_pkey IS NULL"
            case "missing_constraint_marker":q="COMMENT ON CONSTRAINT workflow_template_pkey ON workflow_template IS NULL"
            case "legacy_both":q="COMMENT ON INDEX workflow_template_pkey IS 'tes85:p0:owned:v1'; COMMENT ON CONSTRAINT workflow_template_pkey ON workflow_template IS 'tes85:p0:owned:v1'"
            }
            if q!="" {if _,err:=pool.Exec(ctx,q);err!=nil {t.Fatal(err)}}
            before:=tes85CatalogState(t,ctx,pool)
            if err:=tes85Run(t,pool,ctx,"down",tes85KeyNames()...);err==nil {t.Fatal("unsafe down accepted")}
            if tes85CatalogState(t,ctx,pool)!=before {t.Fatal("refusal mutated catalog/ledger")}
        })
    }
}
