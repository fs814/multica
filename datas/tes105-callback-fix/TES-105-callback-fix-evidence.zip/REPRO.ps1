param([Parameter(Mandatory=$true)][string]$CandidateRoot)
$ErrorActionPreference = 'Stop'
if (-not $env:DATABASE_URL -or $env:DATABASE_URL -notmatch '/tes85_[a-zA-Z0-9_]+(?:\?|$)') {
    throw 'Set DATABASE_URL to a newly prepared, migrated disposable tes85_* database.'
}
$candidate = (Resolve-Path -LiteralPath $CandidateRoot).Path
if ((git -C $candidate rev-parse HEAD) -ne 'f932e6eea7b82631acf6cf02cbef33e2662e7e28') {
    throw 'Unexpected candidate revision'
}
$replace = @{}
$replace[(Join-Path $candidate 'server/internal/handler/review_boundary_test.go')] = Join-Path $PSScriptRoot 'review_boundary_test.go'
$overlay = Join-Path $PSScriptRoot 'review-overlay.json'
[IO.File]::WriteAllText($overlay, (@{Replace=$replace} | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
Push-Location (Join-Path $candidate 'server')
try {
    go build ./...
    if ($LASTEXITCODE -ne 0) { throw 'build failed' }
    go vet ./...
    if ($LASTEXITCODE -ne 0) { throw 'vet failed' }
    go test -p 1 ./internal/handler ./internal/service ./cmd/server -run 'TestR5|TestWorkflow|TestAgentInvoke|TestBatchChildDone|TestBatchUpdate' -count=1 -v
    if ($LASTEXITCODE -ne 0) { throw 'focused tests failed' }
    go test -overlay $overlay ./internal/handler -run '^TestReview105CallbackCaseBoundary$' -count=1 -v
    if ($LASTEXITCODE -ne 0) { throw 'original probe failed' }
    go test ./internal/workflow -count=1 -v
    if ($LASTEXITCODE -ne 0) { throw 'workflow suite failed' }
} finally { Pop-Location }
