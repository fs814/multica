package handler

import (
    "context"
    "fmt"
    "net/http/httptest"
    "testing"
)

// Review-only overlay: the candidate's tracked files remain unchanged.
func TestReview105CallbackCaseBoundary(t *testing.T) {
    cleanupWorkflowTemplates(t)
    cleanupWorkflowRuns(t)
    withWorkflowEngineForTest(t)
    tpl := seededBugFixTemplate(t)
    for index, key := range []string{"callback_destination_id", "CALLBACK_DESTINATION_ID", "Callback_Destination_Id"} {
        t.Run(key, func(t *testing.T) {
            var before, after int
            if err := testPool.QueryRow(context.Background(), "SELECT count(*) FROM workflow_run WHERE workspace_id=$1", testWorkspaceID).Scan(&before); err != nil { t.Fatal(err) }
            body := map[string]any{"source":"review105", "event_id":fmt.Sprint(index), "template_key":tpl.Key, "title":"Review callback boundary", "description":"Reject unsupported callback configuration", key:"00000000-0000-0000-0000-000000000001"}
            rec := httptest.NewRecorder()
            testHandler.WorkflowIntake(rec, withURLParam(newRequest("POST", "/api/workspaces/"+testWorkspaceID+"/workflow-intake", body), "id", testWorkspaceID))
            if err := testPool.QueryRow(context.Background(), "SELECT count(*) FROM workflow_run WHERE workspace_id=$1", testWorkspaceID).Scan(&after); err != nil { t.Fatal(err) }
            t.Logf("callback key=%s status=%d new_runs=%d", key, rec.Code, after-before)
            if rec.Code != 400 || after != before { t.Errorf("unsupported callback must be rejected without materializing a run") }
        })
    }
}
