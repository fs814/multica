param([Parameter(Mandatory=$true)][string]$CandidateRoot)
$ErrorActionPreference = 'Stop'
$candidate = (Resolve-Path -LiteralPath $CandidateRoot).Path
if ((git -C $candidate rev-parse HEAD) -ne 'f932e6eea7b82631acf6cf02cbef33e2662e7e28') { throw 'Unexpected candidate revision' }
if (-not $env:DATABASE_URL -or $env:DATABASE_URL -notmatch '/tes85_[a-zA-Z0-9_]+(?:\?|$)') { throw 'Explicit disposable tes85_* DATABASE_URL required; create and migrate it first.' }
$replace = @{}
$replace[(Join-Path $candidate 'server/internal/handler/review_boundary_test.go')] = Join-Path $PSScriptRoot 'review_boundary_test.go'
$replace[(Join-Path $candidate 'server/internal/handler/review_independent_test.go')] = Join-Path $PSScriptRoot 'independent_test.go'
$overlay = Join-Path $PSScriptRoot 'overlay.local.json'
[IO.File]::WriteAllText($overlay, (@{Replace=$replace}|ConvertTo-Json), [Text.UTF8Encoding]::new($false))
Push-Location (Join-Path $candidate 'server')
try {
 go build ./...
 if ($LASTEXITCODE -ne 0) { throw 'build failed' }
 go vet ./...
 if ($LASTEXITCODE -ne 0) { throw 'vet failed' }
 go test -p 1 ./internal/handler ./internal/service ./cmd/server -run 'TestR5|TestWorkflow|TestAgentInvoke|TestBatchChildDone|TestBatchUpdate' -count=1 -json
 if ($LASTEXITCODE -ne 0) { throw 'focused tests failed' }
 go test ./internal/workflow -count=1 -json
 if ($LASTEXITCODE -ne 0) { throw 'workflow tests failed' }
 go test -overlay $overlay ./internal/handler -run '^TestReview105' -count=1 -json
 if ($LASTEXITCODE -ne 0) { throw 'independent probes failed' }
 # Reconstruct only the original production handler as a negative control.
 $replace.Remove((Join-Path $candidate 'server/internal/handler/review_independent_test.go'))
 $replace[(Join-Path $candidate 'server/internal/handler/workflow_intake.go')] = Join-Path $PSScriptRoot 'before-workflow_intake.go'
 [IO.File]::WriteAllText($overlay, (@{Replace=$replace}|ConvertTo-Json), [Text.UTF8Encoding]::new($false))
 go test -overlay $overlay ./internal/handler -run '^TestReview105CallbackCaseBoundary$' -count=1 -json
 if ($LASTEXITCODE -ne 1) { throw 'Expected original R5 counterexample to fail; inspect the three HTTP/run-count results' }
} finally { Pop-Location }
