package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/multica-ai/multica/server/internal/testutil"
)

// Review-only overlay. The fixed candidate remains untouched.
func TestReview105IndependentBoundary(t *testing.T) {
	cleanupWorkflowTemplates(t)
	cleanupWorkflowRuns(t)
	withWorkflowEngineForTest(t)
	tpl := seededBugFixTemplate(t)
	counts := func(t *testing.T) string {
		t.Helper()
		var result string
		err := testPool.QueryRow(context.Background(), `SELECT jsonb_build_array(
   (SELECT count(*) FROM issue WHERE workspace_id=$1),
   (SELECT count(*) FROM workflow_run WHERE workspace_id=$1),
   (SELECT count(*) FROM workflow_step_instance WHERE workspace_id=$1),
   (SELECT count(*) FROM workflow_event WHERE workspace_id=$1),
   (SELECT count(*) FROM agent_task_queue q JOIN agent a ON a.id=q.agent_id WHERE a.workspace_id=$1),
   (SELECT count(*) FROM issue_subscriber s JOIN issue i ON i.id=s.issue_id WHERE i.workspace_id=$1)
  )::text`, testWorkspaceID).Scan(&result)
		if err != nil {
			t.Fatal(err)
		}
		return result
	}
	post := func(t *testing.T, event, extra string) *testutil.Response {
		t.Helper()
		body := fmt.Sprintf(`{"source":"review105","event_id":%q,"template_key":%q,"title":"Independent boundary","description":"Review callback controls",%s}`, event, tpl.Key, extra)
		req := testutil.JSONRequest("POST", "/api/workspaces/"+testWorkspaceID+"/workflow-intake", body)
		testutil.WithHeaders(req, "X-User-ID", testUserID, "X-Workspace-ID", testWorkspaceID)
		return testutil.Call(t, testHandler.WorkflowIntake, withURLParam(req, "id", testWorkspaceID))
	}
	quote := func(s string) string { b, _ := json.Marshal(s); return string(b) }
	keys := []string{"callback_destination_id", "input_instance_id", "input_instance_revision", "input_source", "execution_mode", "debug_session_id", "template_version_id"}
	n := 0
	for _, key := range keys {
		variants := []string{key, strings.ToUpper(key)}
		// Alter each letter independently, including both special ASCII-equivalent folds.
		for i, c := range key {
			if c >= 'a' && c <= 'z' {
				variants = append(variants, key[:i]+strings.ToUpper(string(c))+key[i+1:])
			}
			if c == 's' {
				variants = append(variants, key[:i]+"ſ"+key[i+1:])
			}
			if c == 'k' {
				variants = append(variants, key[:i]+"K"+key[i+1:])
			}
		}
		for _, variant := range variants {
			escaped := "\""
			for _, c := range variant {
				escaped += fmt.Sprintf(`\u%04x`, c)
			}
			escaped += "\""
			for _, encoded := range []string{quote(variant), escaped} {
				for _, fields := range []string{
					encoded + `:"00000000-0000-0000-0000-000000000001"`,
					encoded + `:"x",` + quote(key) + `:null,` + quote(strings.ToUpper(key)) + `:""`,
					quote(key) + `:"",` + encoded + `:"x",` + encoded + `:null`,
					encoded + `:"\u0000",` + encoded + `:""`,
				} {
					n++
					t.Run(fmt.Sprintf("reject-%04d", n), func(t *testing.T) {
						before := counts(t)
						response := post(t, t.Name(), fields)
						response.Want(400)
						after := counts(t)
						if before != after {
							t.Fatalf("business rows changed: %s -> %s; fields=%s", before, after, fields)
						}
						t.Logf("fields=%s HTTP=400 six-row-counts=%s unchanged", fields, after)
					})
				}
			}
		}
	}
	for i, fields := range []string{
		`"payload":{}`,
		`"CALLBACK_DEſTINATION_ID": null, "callback_destination_id": "", "input_instance_id": "", "input_instance_revision":null,"input_source":"","execution_mode":null,"debug_session_id":"","template_version_id":null`,
		`"payload":{"callback_destination_id":"ordinary data","nested":{"CALLBACK_DESTINATION_ID":"nested data"},"array":[{"execution_mode":"data"}]}`,
	} {
		t.Run(fmt.Sprintf("allowed-%d", i), func(t *testing.T) {
			var first, second WorkflowIntakeResponse
			post(t, t.Name(), fields).Want(201).JSON(&first)
			before := counts(t)
			post(t, t.Name(), fields).Want(200).JSON(&second)
			if first.ReceiptID == "" || first.ReceiptID != second.ReceiptID || first.WorkflowRunID != second.WorkflowRunID || first.IssueID != second.IssueID || counts(t) != before {
				t.Fatal("unstable receipt or replay writes")
			}
			if i == 2 {
				run := getWorkflowRunForTest(t, first.WorkflowRunID)
				var payload map[string]any
				if err := json.Unmarshal(run.Input, &payload); err != nil {
					t.Fatal(err)
				}
				if payload["callback_destination_id"] != "ordinary data" || payload["nested"].(map[string]any)["CALLBACK_DESTINATION_ID"] != "nested data" {
					t.Fatalf("nested content changed: %s", run.Input)
				}
			}
			t.Logf("HTTP=201 then 200; stable receipt; six-row-counts=%s unchanged on replay", before)
		})
	}
}
