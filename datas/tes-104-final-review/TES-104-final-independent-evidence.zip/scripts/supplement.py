from pathlib import Path
import os,re,json,subprocess,datetime,shutil,hashlib
root=Path(__file__).resolve().parent;server=root/'candidate/server';out=root/'results';env=dict(os.environ)
env.update(json.loads(subprocess.check_output(['go','env','-json','GOCACHE','GOMODCACHE','GOPATH'],cwd=server)))
for key,leaf in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/appdata'),('LOCALAPPDATA','home/localappdata'),('XDG_CONFIG_HOME','home/config'),('XDG_CACHE_HOME','home/cache'),('MULTICA_CONFIG_DIR','home/multica')]:env[key]=str(root/leaf)
base=re.search(r'defaultTestDatabaseURL = "([^"]+)"',(server/'cmd/migrate/migrate_concurrent_test.go').read_text())[1].rsplit('/',1)[0]
def db_env(db):return dict(env,DATABASE_URL=base+'/'+db+'?sslmode=disable',TES85_RUN_MIGRATION_TESTS='1')
summary={};owned=[]
def sql(q):
    p=subprocess.run([str(out/'dbprobe.exe')],input=q.encode(),env=db_env('postgres'),capture_output=True)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
    return json.loads(p.stdout)
def run(name,args,cwd=server,extra=None):
    print(name,'running',flush=True)
    with (out/(name+'.log')).open('wb') as f:p=subprocess.run(args,cwd=cwd,env=extra or env,stdout=f,stderr=subprocess.STDOUT)
    events=[]
    for l in (out/(name+'.log')).read_text(errors='replace').splitlines():
        try:events.append(json.loads(l))
        except ValueError:pass
    r={'args':args,'exit':p.returncode,'top':{a:sum(x.get('Action')==a and bool(x.get('Test')) and '/' not in x['Test'] for x in events) for a in ['pass','fail','skip']},'failures':[x for x in events if x.get('Action')=='fail'],'skips':[x for x in events if x.get('Action')=='skip']}
    summary[name]=r;(out/'supplement.json').write_text(json.dumps(summary,indent=2));print(name,p.returncode,r['top'],flush=True)
    return p.returncode
def create(db):
    assert sql("SELECT count(*) FROM pg_database WHERE datname='"+db+"'")==[[0]],'database exists; never reuse'
    sql('CREATE DATABASE "'+db+'"');owned.append(db)
def drop(db):sql('DROP DATABASE "'+db+'"');owned.remove(db)
try:
    names=[n+'_independent_'+datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S') for n in ['tes85Xp0Xreview0916','tes85Xp0_tes104','tes85p0_tes104','tes85_p0Xtes104','tes85_p0tes104','ordinary_tes104','tes85_p0_tes104_review']]
    for db in names:
        create(db)
        run('prefix-'+db,['go','test','./cmd/migrate','-run','^TestTES85DatabasePrefixBoundary$','-count=1','-timeout=1m','-json'],extra=db_env(db))
        drop(db)
    db='tes85_p0_r7_review104_extra_'+datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S');create(db)
    assert run('extra-up',[str(root/'bin/bin/migrate.exe'),'up'],extra=db_env(db))==0
    run('additional-adapters',['go','test','-p','1','./internal/service','./internal/daemon','./pkg/agent','-run','TestBuiltinBugFix|TestBuiltinWorkflow|TestIsBuiltinWorkflow|TestEnsureBuiltinWorkflow|TestWorkflowStepPrompt|TestWorkflowStructuredOutput|TestCodexOutputSchema','-count=1','-timeout=3m','-json'],extra=db_env(db))
    run('full-migration-package',['go','test','./internal/migrations','-count=1','-timeout=3m','-json'],extra=db_env(db))
    drop(db)
    target=root/'sqlc';target.mkdir(exist_ok=True)
    shutil.copy2(server/'sqlc.yaml',target/'sqlc.yaml')
    shutil.copytree(server/'migrations',target/'migrations',dirs_exist_ok=True)
    shutil.copytree(server/'pkg/db/queries',target/'pkg/db/queries',dirs_exist_ok=True)
    def hashes(path):return {p.name:hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in path.glob('*.go')}
    expected=hashes(server/'pkg/db/generated')
    assert run('sqlc-generate',['sqlc','generate'],cwd=target)==0
    first=hashes(target/'pkg/db/generated')
    assert run('sqlc-repeat',['sqlc','generate'],cwd=target)==0
    second=hashes(target/'pkg/db/generated')
    summary['sqlc']={'files':len(second),'matches_candidate_normalized':expected==first,'repeat_equal':first==second,'differences':[k for k in set(expected)|set(first) if expected.get(k)!=first.get(k)]}
finally:
    for db in list(owned):drop(db)
    summary['database_cleanup_verified']=all(sql("SELECT count(*) FROM pg_database WHERE datname='"+db+"'")==[[0]] for db in names+[db])
    (out/'supplement.json').write_text(json.dumps(summary,indent=2))
    print('summary',summary.get('sqlc'),'cleanup',summary['database_cleanup_verified'],flush=True)
