from pathlib import Path
import os,re,json,subprocess,datetime,hashlib
root=Path(__file__).resolve().parent; repo=root/'candidate'; server=repo/'server'; results=root/'results';results.mkdir(exist_ok=True)
env=dict(os.environ)
cache=json.loads(subprocess.check_output(['go','env','-json','GOCACHE','GOMODCACHE','GOPATH'],cwd=server))
env.update(cache)
for key,leaf in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/appdata'),('LOCALAPPDATA','home/localappdata'),('XDG_CONFIG_HOME','home/config'),('XDG_CACHE_HOME','home/cache'),('MULTICA_CONFIG_DIR','home/multica')]:
    p=root/leaf;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
host=Path(os.environ['USERPROFILE'])/'.multica/config.json'
def stamp():
    if not host.exists():return None
    s=host.stat();return {'size':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':hashlib.sha256(host.read_bytes()).hexdigest()}
before=stamp()
url=re.search(r'defaultTestDatabaseURL = "([^"]+)"',(server/'cmd/migrate/migrate_concurrent_test.go').read_text())[1]
db='tes85_p0_r7_review104_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
def db_env(name):return dict(env,DATABASE_URL=url.rsplit('/',1)[0]+'/'+name+'?sslmode=disable')
env=db_env(db)
summary={}
def run(name,args,e=None):
    print(name,'running',flush=True)
    with (results/(name+'.log')).open('wb') as f:
        p=subprocess.run(args,cwd=server,env=e or env,stdout=f,stderr=subprocess.STDOUT)
    events=[]
    for l in (results/(name+'.log')).read_text(errors='replace').splitlines():
        try:events.append(json.loads(l))
        except ValueError:pass
    result={'args':args,'exit':p.returncode,'top':{a:sum(x.get('Action')==a and bool(x.get('Test')) and '/' not in x['Test'] for x in events) for a in ['pass','fail','skip']},'sub':{a:sum(x.get('Action')==a and '/' in x.get('Test','') for x in events) for a in ['pass','fail','skip']},'failures':[x for x in events if x.get('Action')=='fail'],'skips':[x for x in events if x.get('Action')=='skip']}
    summary[name]=result;(results/'tests.json').write_text(json.dumps(summary,indent=2))
    print(name,p.returncode,result['top'],result['sub'],flush=True)
    return p.returncode
def sql(q,name=db):
    p=subprocess.run([str(results/'dbprobe.exe')],input=q.encode(),cwd=server,env=db_env(name),capture_output=True)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
    return json.loads(p.stdout)
assert run('build-dbprobe',['go','build','-o',str(results/'dbprobe.exe'),str(root/'source/dbprobe.go')])==0
owned=False
try:
    sql('CREATE DATABASE "'+db+'"','postgres');owned=True
    summary['database']={'name':db,'identity':sql("SELECT current_database(),version(),system_identifier::text FROM pg_control_system()")}
    assert run('migrate-up',[str(root/'bin/bin/migrate.exe'),'up'])==0
    ledger=sql('SELECT count(*) FROM schema_migrations')
    assert run('migrate-repeat',[str(root/'bin/bin/migrate.exe'),'up'])==0
    assert ledger==sql('SELECT count(*) FROM schema_migrations')
    summary['ledger_count']=ledger
    run('build',['go','build','./...'])
    run('vet',['go','vet','./...'])
    run('focused',['go','test','-p','1','./internal/handler','./internal/service','./cmd/server','-run','TestR5|TestR6|TestWorkflow|TestAgentInvoke|TestBatchChildDone|TestBatchUpdate|TestStableIDSuffixMatchesDaemon|TestParseSkillArchive','-count=1','-timeout=5m','-json'])
    run('workflow',['go','test','./internal/workflow','-count=1','-timeout=5m','-json'])
    run('migration',['go','test','-p','1','./internal/migrations','./cmd/migrate','-run','TestMigration|TestHistoricalMigration|TestTES85','-count=1','-timeout=5m','-json'],dict(env,TES85_RUN_MIGRATION_TESTS='1'))
    replacements={str(server/'cmd/migrate/review104_test.go'):str(root/'history/old-review/review104_test.go'),str(server/'internal/handler/review105_test.go'):str(root/'history/callback/source/independent_test.go')}
    overlay=root/'overlay.json';overlay.write_text(json.dumps({'Replace':replacements}))
    run('independent-probes',['go','test','-overlay',str(overlay),'-p','1','./cmd/migrate','./internal/handler','-run','TestReview104|TestReview105Independent','-count=1','-timeout=5m','-json'],dict(env,TES85_RUN_MIGRATION_TESTS='1'))
    run('handler',['go','test','./internal/handler','-count=1','-timeout=5m','-json'])
finally:
    if owned:
        sql('DROP DATABASE "'+db+'"','postgres')
        summary['database']['dropped']=sql("SELECT count(*) FROM pg_database WHERE datname='"+db+"'",'postgres')==[[0]]
    summary['host_config_unchanged']=before==stamp()
    summary['identity_markers_preserved']=all(env.get(k)==v for k,v in os.environ.items() if k.startswith('MULTICA_') and k!='MULTICA_CONFIG_DIR')
    (results/'tests.json').write_text(json.dumps(summary,indent=2))
    print('cleanup',summary.get('database'),'host_config_unchanged',summary['host_config_unchanged'],flush=True)
