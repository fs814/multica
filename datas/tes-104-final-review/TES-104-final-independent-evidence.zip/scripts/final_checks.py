from pathlib import Path
import subprocess,hashlib,json,re,collections,shutil
root=Path(__file__).resolve().parent;repo=root/'candidate';out=root/'results'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={}
target=root/'sqlc/pkg/db/generated'
for name in ['comment_row.go','attachment_row.go']:shutil.copy2(repo/'server/pkg/db/generated'/name,target/name)
def hashes(directory,normalize=False):return {p.name:hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n') if normalize else p.read_bytes()).hexdigest() for p in directory.glob('*.go')}
before=hashes(target)
for n in [1,2]:
    p=subprocess.run(['sqlc','generate'],cwd=root/'sqlc',capture_output=True)
    (out/('sqlc-confirm-'+str(n)+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0
    assert before==hashes(target)
assert hashes(target,True)==hashes(repo/'server/pkg/db/generated',True)
report['sqlc']={'generated':59,'handwritten_helpers':2,'total_files':61,'two_repeat_bytes_equal':True,'matches_candidate_except_line_endings':True}
old='0ca4c63c0dd02e00c2fdacc9d8c4f480e291f815'
deps=['server/go.mod','server/go.sum','server/internal/attributionbackfill','server/internal/chatoriginbackfill','server/internal/dbstartup','server/internal/logger','server/internal/taskusagebackfill']
report['migration_dependencies']={}
for path in deps:
    a=git('rev-parse',old+':'+path);b=git('rev-parse','HEAD:'+path);assert a==b
    report['migration_dependencies'][path]=a
files=git('ls-tree','--name-only','fa698dcfc5f143a5c5c372944dbafb2b2ae2577b:server/migrations').splitlines()
groups=collections.defaultdict(list)
for f in files:
    if f.endswith('.up.sql'):
        n=int(f.split('_',1)[0])
        if n>=129:groups[n].append(f[:-7])
dups={n:sorted(v) for n,v in groups.items() if len(v)>1}
code=(repo/'server/internal/migrations/migrations_lint_test.go').read_text()
actual={int(n):re.findall(r'"([^"]+)"',v) for n,v in re.findall(r'^\s*(\d+):\s*\{([^}]+)\}',code,re.M)}
assert actual==dups
report['independent_freeze']={'groups':len(dups),'stems':sum(map(len,dups.values())),'matches_R6_exactly':True}
history=root/'history/r3/source';verified=0
for line in (history/'SHA256SUMS.txt').read_text().splitlines():
    h,n=line.split(None,1);assert sha(history/n.lstrip('* '))==h;verified+=1
report['historical_R3_manifest_files']=verified
assert git('show','9d18186e6e8cfa168d6053d33d652e86fadfc12b:server/migrations/478_issue_status_category_expand.up.sql')==git('show','HEAD:server/migrations/478_issue_status_category_expand.up.sql')
report['478_matches_upstream']=True
report['go_version']=subprocess.check_output(['go','version'],cwd=repo/'server').decode().strip()
report['sqlc_version']=subprocess.check_output(['sqlc','version']).decode().strip()
report['git_status']=git('status','--porcelain');assert report['git_status']==''
(out/'final-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
