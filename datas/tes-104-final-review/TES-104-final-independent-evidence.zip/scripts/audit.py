from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parent
src=root/'source'; repo=root/'candidate'; out=root/'results';out.mkdir(exist_ok=True)
def git(*args): return subprocess.check_output(['git','-C',str(repo),*args])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
report={}
for directory,manifest in [(src,'MANIFEST.sha256'),(root/'bin','WINDOWS-MANIFEST.sha256')]:
    rows=[]
    for line in (directory/manifest).read_text().splitlines():
        h,name=line.split(None,1);name=name.lstrip('* ')
        assert (directory/name).resolve().is_relative_to(directory.resolve())
        assert sha(directory/name)==h,(name,'hash mismatch')
        rows.append(name)
    report[manifest]=len(rows)
c=json.loads((src/'CANDIDATE.json').read_text())
assert git('rev-parse','HEAD').decode().strip()==c['refs']['final']
report['trees']={}
for label,trees in c['trees'].items():
    report['trees'][label]={}
    for path,expected in trees.items():
        actual=git('rev-parse',c['refs'][label]+':'+path).decode().strip()
        assert actual==expected,(label,path)
        report['trees'][label][path]=actual
report['diffs']={}
for label,expected in c['changes'].items():
    actual=git('diff','--name-status',c['refs'][label],c['refs']['final']).decode().splitlines()
    assert actual==expected,label
    patch=git('diff','--binary',c['refs'][label],c['refs']['final'])
    assert patch==(src/('final-from-'+label+'.patch')).read_bytes(),label
    report['diffs'][label]=len(actual)
report['binary']={}
for name,info in c['binaries'].items():
    p=root/'bin'/name
    if not p.exists():p=root/'bin'/'bin'/name
    assert sha(p)==info['sha256'] and p.stat().st_size==info['bytes'],name
    meta=subprocess.check_output(['go','version','-m',str(p)],cwd=repo/'server').decode()
    assert 'vcs.revision='+c['refs']['final'] in meta and 'vcs.modified=false' in meta
    (out/(name+'.build.txt')).write_text(meta)
    report['binary'][name]=info
report['migration_files']=0
for p in (root/'bin'/'migrations').iterdir():
    blob=git('show',c['refs']['final']+':server/migrations/'+p.name)
    assert blob.replace(b'\r\n',b'\n')==p.read_bytes().replace(b'\r\n',b'\n'),p.name
    report['migration_files']+=1
a=git('diff','--binary',c['refs']['callback_original']+'^',c['refs']['callback_original'])
b=git('diff','--binary',c['refs']['callback_integrated']+'^',c['refs']['callback_integrated'])
assert a==b==(src/'callback-original.patch').read_bytes()
report['callback_patch_equal']=True
report['head']=c['refs']['final']
report['candidate_status']=git('status','--porcelain').decode()
(out/'provenance.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
